import hashlib
import hmac
import json
import math
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.config import Settings
from app.cvat import CvatError
from app.learning import classify_frame, derive_profile
from app.main import create_app
from app.planning import plan_agents
from app.service import apply_profile_to_shape, label_patch, review_reasons
from app.spec import diff_labels, extract_spec
from app.geometry import crosses_self, outline_is_template, resample_polygon, simplify_polygon
from app.service import associate_by_iou


DOCUMENT = """
Output format: CVAT

Label: pothole
Type: polygon
Min size: 30
Attribute: severity
Input: select
Values: low, medium, high
Default: medium
Required: yes

Label: car
Type: rectangle
Attribute: moving
Input: checkbox
Values: true, false
Default: false
Required: no

Label: crack
Min size: 10
"""


def test_spec_questions_and_idempotent_diff():
    parsed = extract_spec(DOCUMENT)
    names = {label["name"]: label["type"] for label in parsed["labels"]}
    assert names["pothole"] == "polygon"
    assert names["car"] == "rectangle"
    assert any(question["id"] == "crack:type" for question in parsed["questions"])
    diff = diff_labels(parsed, [])
    assert {item["name"] for item in diff["create"]} == {"pothole", "car"}
    assert any(item["name"] == "crack" for item in diff["blocked"])
    existing = [
        {
            "id": 1,
            "name": "pothole",
            "type": "polygon",
            "attributes": [
                {
                    "id": 9,
                    "name": "severity",
                    "input_type": "select",
                    "values": ["low", "medium", "high"],
                    "default_value": "medium",
                }
            ],
        },
        {"id": 2, "name": "car", "type": "rectangle", "attributes": [
            {"id": 10, "name": "moving", "input_type": "checkbox", "values": ["true", "false"], "default_value": "false"}
        ]},
    ]
    again = diff_labels(parsed, existing)
    assert again["create"] == []
    assert again["update"] == []
    assert set(again["unchanged"]) == {"pothole", "car"}
    patch = label_patch(diff, [], confirm=False)
    assert all("deleted" not in item for item in patch)


PROSE = """
Annotate vehicles and road defects. Defects are outlined as polygons.
Ignore objects smaller than 20 px
Label: vehicle
Definition: Any motorised road vehicle: car, van, truck, bus, motorcycle.
Draw the box around the whole vehicle including mirrors
Label: road_defect
Definition: Visible damage on the road surface.
The road_defect row uses the segmentation-polygon format.
{
  "categories": [{"id": 1, "name": "vehicle"}, {"id": 2, "name": "road_defect"}],
  "annotations": [
    {"category_id": 1, "bbox": [1, 2, 3, 4], "attributes": {"color": "white"}},
    {"category_id": 2, "segmentation": [[1, 2, 3, 4, 5, 6]], "attributes": {"severity": "medium"}}
  ]
}
4. Notes
Existing annotations found
COCO: car, truck
"""


def test_requirement_guide_explains_type_drawing_and_decision():
    from app.spec import apply_guide, explain_requirement

    parsed = extract_spec(PROSE)
    guide = explain_requirement(parsed)
    decisions = {item["name"]: item for item in guide["decisions"]}
    assert decisions["vehicle"]["type"] == "rectangle"
    assert "box" in decisions["vehicle"]["how_to_annotate"].lower()
    assert "20 px" in decisions["vehicle"]["how_to_decide"]
    assert "color" in decisions["vehicle"]["how_to_decide"]
    assert decisions["road_defect"]["type"] == "polygon"
    assert "boundary" in decisions["road_defect"]["how_to_annotate"].lower()
    merged = apply_guide(parsed, {
        "summary": guide["summary"],
        "workflow": guide["workflow"],
        "decisions": [
            {**decisions["vehicle"], "type": "polygon"},
            decisions["road_defect"],
        ],
    })
    labels = {item["name"]: item for item in merged["labels"]}
    assert labels["vehicle"]["type"] == "rectangle"
    assert labels["vehicle"]["how_to_decide"]
    assert merged["guide"]["decisions"][0]["how_to_annotate"]


def test_skeleton_connections_follow_the_requirement():
    from app.service import _label_create_body, skeleton_ids_to_replace
    from app.spec import HUMAN_KEYPOINTS, skeleton_svg

    document = """
Label: person
Type: skeleton
Keypoints: nose, left_shoulder, neck
Connections: nose-neck, neck-left_shoulder
"""
    parsed = extract_spec(document)
    label = parsed["labels"][0]
    assert label["edges"] == [["nose", "neck"], ["neck", "left_shoulder"]]
    svg = skeleton_svg(label["keypoints"], label["edges"])
    assert 'data-node-from="1" stroke-width="0.5" data-node-to="3"' in svg
    assert 'data-node-from="1" stroke-width="0.5" data-node-to="2"' not in svg
    body = _label_create_body(label)
    assert [item["name"] for item in body["sublabels"]] == ["nose", "left_shoulder", "neck"]
    chained = skeleton_svg(list(HUMAN_KEYPOINTS))
    assert 'data-node-from="10" stroke-width="0.5" data-node-to="11"' not in chained
    existing = [{
        "id": 9,
        "name": "person",
        "type": "skeleton",
        "svg": skeleton_svg(["nose", "left_shoulder", "neck"], [["nose", "left_shoulder"]]),
        "sublabels": [{"name": "nose"}, {"name": "left_shoulder"}, {"name": "neck"}],
    }]
    assert skeleton_ids_to_replace(parsed, existing) == [9]


def test_skeleton_properties_become_a_project_label_without_a_label_heading():
    from app.spec import apply_guide

    document = """
Skeleton properties
The person is annotated as a skeleton.
Keypoints: nose, left_shoulder, right_shoulder
"""
    parsed = extract_spec(document)
    labels = {item["name"]: item for item in parsed["labels"]}
    assert labels["person"]["type"] == "skeleton"
    assert labels["person"]["keypoints"] == ["nose", "left_shoulder", "right_shoulder"]
    added = apply_guide({"labels": [], "questions": [], "tracking": False}, {
        "summary": "A pose.",
        "workflow": "Place every joint.",
        "tracking": False,
        "decisions": [{
            "name": "hand",
            "type": "skeleton",
            "keypoints": ["wrist", "thumb"],
            "why_this_type": "The properties describe a skeleton.",
            "how_to_annotate": "Place each joint.",
            "how_to_decide": "A hand is visible.",
        }],
    })
    hand = {item["name"]: item for item in added["labels"]}["hand"]
    assert hand["type"] == "skeleton"
    assert hand["keypoints"] == ["wrist", "thumb"]


def test_requirement_can_add_skeleton_keypoints_and_tracking():
    from app.spec import explain_requirement

    document = """
Label: person
Draw a human skeleton. Keypoints: nose, left_shoulder, right_shoulder
Track the person across frames.

Label: wheel
Type: ellipse
"""
    parsed = extract_spec(document)
    labels = {item["name"]: item for item in parsed["labels"]}
    assert labels["person"]["type"] == "skeleton"
    assert labels["person"]["keypoints"] == ["nose", "left_shoulder", "right_shoulder"]
    assert labels["wheel"]["type"] == "ellipse"
    assert parsed["tracking"] is True
    guide = explain_requirement(parsed)
    person = {item["name"]: item for item in guide["decisions"]}["person"]
    assert "nose" in person["how_to_decide"]
    assert guide["tracking"] is True
    patch = label_patch(diff_labels(parsed, []), [], False)
    skeleton = next(item for item in patch if item["name"] == "person")
    assert [item["name"] for item in skeleton["sublabels"]] == ["nose", "left_shoulder", "right_shoulder"]
    assert 'data-label-name="nose"' in skeleton["svg"]
    assert next(item for item in patch if item["name"] == "wheel")["type"] == "ellipse"


def test_real_requirement_wording_becomes_labels():
    parsed = extract_spec(PROSE)
    labels = {item["name"]: item for item in parsed["labels"]}
    assert labels["vehicle"]["type"] == "rectangle"
    assert "car" in labels["vehicle"]["detect_as"]
    assert labels["vehicle"]["min_size"] == 20
    assert any(attr["name"] == "color" for attr in labels["vehicle"]["attributes"])
    assert labels["road_defect"]["type"] == "polygon"
    assert labels["road_defect"]["detect_as"] == []
    assert any(attr["name"] == "severity" for attr in labels["road_defect"]["attributes"])
    assert parsed["questions"] == []


def test_detector_aliases_map_onto_the_project_label():
    from app.service import shapes_for_labels

    kept = shapes_for_labels(
        [{"label": "car", "type": "rectangle", "points": [0, 0, 10, 10], "score": 0.9, "attributes": {}}],
        [{"name": "vehicle", "type": "rectangle", "detect_as": ["car", "truck", "bus", "motorbike"]}],
        {"rules": []},
    )
    assert kept[0]["label"] == "vehicle"


def test_agent_plan_uses_only_deployed_models():
    labels = [
        {"name": "car", "type": "rectangle"},
        {"name": "pothole", "type": "polygon"},
        {"name": "lane", "type": "polyline"},
    ]
    plan = {item["label"]: item for item in plan_agents(labels, allow_external=False)}
    assert plan["car"]["agent"] == "claude_vision"
    assert plan["pothole"]["agent"] == "claude_vision"
    assert "CVAT's own models are not used" in plan["pothole"]["reason"]
    assert plan["lane"]["agent"] == "claude_vision"


def test_one_correction_is_not_yet_a_rule():
    from app.learning import prompt_lessons

    samples = [
        {
            "frame_key": "4:0",
            "items": [
                {
                    "role": "correction",
                    "agent": {"label": "car", "type": "rectangle", "points": [0, 0, 100, 80], "attributes": {}},
                    "human": {"label": "car", "type": "rectangle", "points": [5, 4, 90, 70], "attributes": {}},
                }
            ],
        }
    ]
    profile = derive_profile(samples, {"labels": [{"name": "car", "type": "rectangle"}]})
    assert not any(rule["kind"] == "box_offset" and rule["status"] == "active" for rule in profile["rules"])
    lessons = prompt_lessons(profile, samples)
    assert not any("left +5px" in lesson for lesson in lessons)


def test_three_corrections_on_two_images_become_a_rule():
    from app.learning import prompt_lessons

    samples = []
    for image in ("a", "b"):
        for _ in range(2):
            samples.append(
                {
                    "frame_key": image,
                    "items": [
                        {
                            "role": "correction",
                            "agent": {"label": "car", "type": "rectangle", "points": [0, 0, 100, 80], "attributes": {}},
                            "human": {"label": "car", "type": "rectangle", "points": [5, 4, 90, 70], "attributes": {}},
                        }
                    ],
                }
            )
    profile = derive_profile(samples, {"labels": [{"name": "car", "type": "rectangle"}]})
    assert any(rule["kind"] == "box_offset" and rule["status"] == "active" for rule in profile["rules"])
    lessons = prompt_lessons(profile, samples)
    assert any("left +5px" in lesson and "car" in lesson for lesson in lessons)


def test_deleted_masks_do_not_hide_every_later_detection():
    rle = [0, 40, 8, 80, 0.0, 0.0, 10.0, 20.0]
    items = classify_frame(
        [{"label": "human", "type": "mask", "points": [0, 0, 10, 20], "score": 0.9}],
        [{"label": "human", "type": "mask", "points": rle, "source": "auto"}],
    )
    assert items[0]["role"] != "deleted"
    samples = []
    for image in ("a", "b"):
        for _ in range(3):
            samples.append(
                {
                    "frame_key": image,
                    "items": [{"role": "deleted", "agent": {"label": "human", "type": "mask", "points": [0, 0, 10, 20], "score": 0.94}}],
                }
            )
    profile = derive_profile(samples, {"labels": [{"name": "human", "type": "mask"}]})
    assert not any(rule["kind"] == "confidence_cutoff" for rule in profile["rules"])


def test_one_drawing_does_not_become_a_rule():
    samples = [
        {
            "frame_key": "1:0",
            "items": [{"role": "human", "human": {"label": "car", "type": "rectangle", "points": [0, 0, 10, 10], "attributes": {}}}],
        }
    ]
    profile = derive_profile(samples, {"labels": [{"name": "car", "type": "rectangle"}]})
    assert profile["rules"] == []


def _human_car(image: str, box):
    return {
        "frame_key": image,
        "items": [{"role": "human", "human": {"label": "car", "type": "rectangle", "points": box, "attributes": {"moving": "false"}}}],
    }


def test_habits_need_several_images_and_stay_inside_one_project():
    boxes = [
        [0, 0, 40, 20],
        [2, 2, 42, 22],
        [1, 1, 39, 19],
        [0, 1, 41, 21],
        [3, 0, 44, 20],
        [1, 2, 40, 22],
    ]
    samples = [_human_car(f"job:{index % 3}", box) for index, box in enumerate(boxes)]
    profile = derive_profile(samples, {"labels": [{"name": "car", "type": "rectangle", "attributes": []}]})
    assert any(rule["kind"] == "size_range" and rule["status"] == "active" for rule in profile["rules"])
    other = derive_profile([], {"labels": []})
    assert other["rules"] == []


def test_correction_changes_the_next_box_and_point_count():
    corrections = []
    for image in ("a", "b"):
        for _ in range(2):
            corrections.append(
                {
                    "frame_key": image,
                    "items": [
                        {
                            "role": "correction",
                            "agent": {"label": "car", "type": "rectangle", "points": [0, 0, 100, 80], "score": 0.9},
                            "human": {"label": "car", "type": "rectangle", "points": [5, 4, 90, 70], "attributes": {}},
                        }
                    ],
                }
            )
    profile = derive_profile(corrections, {"labels": [{"name": "car", "type": "rectangle"}]})
    adjusted = apply_profile_to_shape(
        {"label": "car", "type": "rectangle", "points": [0, 0, 100, 80], "score": 0.9, "attributes": {}},
        profile,
        "rectangle",
    )
    assert adjusted["points"][0] == 5
    assert adjusted["points"][2] == 90

    polygons = []
    for image in ("p", "q"):
        for _ in range(2):
            polygons.append(
                {
                    "frame_key": image,
                    "items": [
                        {
                            "role": "correction",
                            "agent": {
                                "label": "pothole",
                                "type": "polygon",
                                "points": [0, 0, 30, 0, 30, 30, 20, 30, 10, 30, 0, 30],
                            },
                            "human": {"label": "pothole", "type": "polygon", "points": [2, 2, 28, 2, 28, 28, 2, 28]},
                        }
                    ],
                }
            )
    poly_profile = derive_profile(polygons, {"labels": [{"name": "pothole", "type": "polygon"}]})
    dense = [0, 0, 10, 0, 20, 0, 30, 0, 30, 10, 30, 20, 30, 30, 20, 30, 10, 30, 0, 30, 0, 20, 0, 10]
    thinned = apply_profile_to_shape(
        {"label": "pothole", "type": "polygon", "points": dense, "attributes": {}},
        poly_profile,
        "polygon",
    )
    assert len(thinned["points"]) // 2 == 4
    bent = [0, 0, 40, 0, 40, 10, 20, 10, 20, 30, 0, 30]
    assert len(simplify_polygon(bent)) // 2 == 6
    assert outline_is_template([0, 0, 10, 0, 10, 10, 0, 10])
    circle = []
    for step in range(8):
        circle.extend((math.cos(step * math.pi / 4) * 30, math.sin(step * math.pi / 4) * 30))
    assert outline_is_template(circle)


def test_incomplete_mask_is_completed_from_the_missing_region():
    cv2 = pytest.importorskip("cv2")
    numpy = pytest.importorskip("numpy")
    from app.segment import _complete_mask, _missing_region_prompts, mask_quality

    box = (20.0, 20.0, 120.0, 80.0)
    partial = numpy.zeros((100, 160), numpy.uint8)
    cv2.rectangle(partial, (20, 44), (120, 80), 1, -1)  # roof band (rows 20-43) is missing
    first = mask_quality(partial, box, 160, 100)
    assert first["ok"] is False
    assert first["gaps"]["top"] > 0.3
    prompts = _missing_region_prompts(first, box, partial, 160, 100)
    assert prompts and prompts[0][2] == 1.0
    assert 20 <= prompts[0][1] < 44

    full = numpy.zeros((100, 160), numpy.uint8)
    cv2.rectangle(full, (20, 20), (120, 80), 1, -1)
    cv2.rectangle(full, (30, 20), (110, 24), 0, -1)
    assert mask_quality(full, box, 160, 100)["ok"] is True

    leaking = numpy.zeros((100, 160), numpy.uint8)
    cv2.rectangle(leaking, (0, 0), (159, 99), 1, -1)
    assert mask_quality(leaking, box, 160, 100)["ok"] is False

    calls = []

    class FakeSession:
        pass

    import app.segment as segment

    original = segment._decode_full

    def fake_decode(session, embedding, width, height, box_, extras=None, mask_input=None):
        calls.append(list(extras or []))
        return full.copy(), None

    segment._decode_full = fake_decode
    try:
        result = _complete_mask(FakeSession(), None, 160, 100, box, [], partial, None, "car")
    finally:
        segment._decode_full = original
    assert calls, "a refinement pass should run when the roof is missing"
    assert mask_quality(result, box, 160, 100)["ok"] is True
    assert int(result.sum()) > int(partial.sum())


def test_mask_contour_follows_the_object_and_keeps_separate_parts():
    cv2 = pytest.importorskip("cv2")
    numpy = pytest.importorskip("numpy")
    from app.segment import mask_to_polygons

    mask = numpy.zeros((80, 120), numpy.uint8)
    cv2.ellipse(mask, (40, 40), (28, 16), 0, 0, 360, 1, -1)
    cv2.circle(mask, (100, 20), 12, 1, -1)
    high = mask_to_polygons(mask, 120, 80, "high")
    optimized = mask_to_polygons(mask, 120, 80, "optimized")
    assert len(high) == 2
    assert max(len(item) for item in high) > max(len(item) for item in optimized)
    for polygon in high:
        assert len(polygon) // 2 >= 6
        assert all(0 <= x < 120 and 0 <= y < 80 for x, y in zip(polygon[0::2], polygon[1::2]))
    assert mask_to_polygons(numpy.zeros((20, 20), numpy.uint8), 20, 20) == []
    from app.segment import _place_decoder_mask

    crop = numpy.zeros((5, 4), numpy.uint8)
    crop[1:4, 1:3] = 1
    placed = _place_decoder_mask(crop, 10, 8, 30, 20)
    assert placed.shape == (20, 30)
    assert int(placed.sum()) == 6
    assert placed[9, 11] == 1
    from app.segment import _artificial_diagonal, _decode_cvat_rle, binary_to_cvat_rle
    from app.service import to_cvat_shape

    person = numpy.zeros((60, 40), numpy.uint8)
    cv2.ellipse(person, (20, 12), (8, 8), 0, 0, 360, 1, -1)
    cv2.rectangle(person, (14, 18), (26, 40), 1, -1)
    cv2.rectangle(person, (16, 40), (20, 55), 1, -1)
    cv2.rectangle(person, (22, 40), (26, 54), 1, -1)
    rle = binary_to_cvat_rle(person)
    assert rle is not None
    assert int((_decode_cvat_rle(rle, 40, 60) != person).sum()) == 0
    saved = to_cvat_shape(
        {"label": "human", "type": "mask", "points": rle, "encoded": "rle"},
        {"human": {"id": 9, "name": "human", "attributes": []}},
        11,
    )
    assert saved["type"] == "mask"
    assert saved["points"] == [float(value) for value in rle]
    assert to_cvat_shape(
        {"label": "human", "type": "mask", "points": [320, 428, 550, 768]},
        {"human": {"id": 9, "name": "human", "attributes": []}},
        11,
    ) is None
    assert _artificial_diagonal([10, 10, 40, 10, 40, 80]) is True
    assert review_reasons({"label": "person", "type": "polygon", "points": [0, 0, 2, 0, 1, 2], "review": "Check the outline."}, None, None) == ["Check the outline."]


def test_detector_names_match_task_labels_and_drop_duplicates():
    from app.detect import dedupe_shapes, is_detector_label, labels_needing_vision, match_label
    from app.service import shapes_for_labels, to_cvat_shape

    labels = [
        {"name": "human", "type": "mask"},
        {"name": "vehicle", "type": "polygon", "detect_as": ["car", "truck"]},
        {"name": "pothole", "type": "polygon"},
    ]
    assert match_label("person", labels)["name"] == "human"
    assert match_label("car", labels)["name"] == "vehicle"
    assert match_label("motorcycle", labels) is None
    assert match_label("pothole", labels)["name"] == "pothole"
    assert is_detector_label(labels[0]) and not is_detector_label(labels[2])
    found = [{"label": "human", "type": "mask", "points": [0, 0, 10, 40], "score": 0.9}]
    pending = labels_needing_vision(labels, found)
    assert [item["name"] for item in pending] == ["vehicle", "pothole"]
    boxes = [
        {"label": "human", "type": "mask", "points": [0, 0, 10, 40], "score": 0.9},
        {"label": "human", "type": "mask", "points": [1, 1, 11, 41], "score": 0.4},
        {"label": "human", "type": "mask", "points": [80, 0, 100, 40], "score": 0.8},
    ]
    assert len(dedupe_shapes(boxes)) == 2
    adapted = shapes_for_labels(
        [{"label": "person", "type": "mask", "points": [0, 0, 10, 40], "score": 0.8}],
        labels,
        None,
    )
    assert adapted[0]["label"] == "human"
    assert to_cvat_shape(
        {"label": "vehicle", "type": "polygon", "points": [0, 0, 10, 0, 10, 10, 0, 10]},
        {"vehicle": {"id": 1, "name": "vehicle", "attributes": []}},
        0,
    ) is None


def test_classification_does_not_double_count():
    snapshot = [{"label": "car", "type": "rectangle", "points": [0, 0, 10, 10], "attributes": {}, "source": "auto"}]
    final = [
        {"label": "car", "type": "rectangle", "points": [0, 0, 10, 10], "attributes": {}, "source": "auto"},
        {"label": "pothole", "type": "polygon", "points": [1, 1, 4, 1, 2, 4], "attributes": {}, "source": "manual"},
        {"label": "car", "type": "rectangle", "points": [50, 50, 60, 60], "attributes": {}, "source": "file"},
    ]
    roles = [item["role"] for item in classify_frame(snapshot, final)]
    assert roles.count("untouched") == 1
    assert roles.count("human") == 1
    assert roles.count("imported") == 1
    human_only = classify_frame([], [final[1]])
    assert human_only[0]["role"] == "human"


def test_spec_conflict_is_not_applied():
    rows = []
    for image in ("a", "b"):
        for _ in range(2):
            rows.append(
                {
                    "frame_key": image,
                    "items": [
                        {
                            "role": "correction",
                            "agent": {"label": "car", "type": "rectangle", "points": [0, 0, 10, 10]},
                            "human": {"label": "truck", "type": "rectangle", "points": [0, 0, 10, 10], "attributes": {}},
                        }
                    ],
                }
            )
    profile = derive_profile(
        rows,
        {"labels": [{"name": "car", "type": "rectangle"}, {"name": "truck", "type": "rectangle"}]},
    )
    rule = next(rule for rule in profile["rules"] if rule["kind"] == "label_confusion")
    assert rule["status"] == "conflict"
    kept = apply_profile_to_shape(
        {"label": "car", "type": "rectangle", "points": [0, 0, 10, 10], "attributes": {}},
        profile,
        "rectangle",
    )
    assert kept["label"] == "car"


def test_tracking_keeps_shape_and_id_across_a_gap():
    from app.service import to_cvat_tracks

    polygon = [0, 0, 30, 0, 40, 20, 28, 40, 8, 36, 0, 18]
    moved = [8, 4, 38, 4, 48, 24, 36, 44, 16, 40, 8, 22]
    linked = associate_by_iou(
        {
            0: [{"label": "person", "type": "polygon", "points": polygon, "score": 0.9}],
            2: [{"label": "person", "type": "polygon", "points": moved, "score": 0.8}],
            3: [
                {"label": "person", "type": "polygon", "points": moved, "score": 0.8},
                {"label": "sign", "type": "rectangle", "points": [0, 0, 10, 10], "score": 0.7},
            ],
        }
    )
    assert linked[0][0]["track_id"] == linked[2][0]["track_id"] == linked[3][0]["track_id"]
    assert linked[3][1]["track_id"] != linked[3][0]["track_id"]
    assert linked[3][0]["type"] == "polygon"
    points = associate_by_iou(
        {
            0: [{"label": "joint", "type": "points", "points": [10, 10, 20, 12]}],
            1: [{"label": "joint", "type": "points", "points": [12, 11, 22, 13]}],
        }
    )
    assert points[0][0]["track_id"] == points[1][0]["track_id"]
    labels = {"person": {"id": 4, "name": "person", "attributes": []}}
    tracks = to_cvat_tracks({0: linked[0], 2: linked[2]}, labels)
    assert tracks[0]["shapes"][0]["type"] == "polygon"
    assert tracks[0]["shapes"][1]["outside"] is True
    assert tracks[0]["shapes"][2]["type"] == "polygon"
    mask = associate_by_iou(
        {
            0: [{"label": "human", "type": "mask", "encoded": "rle", "points": [0, 5, 1, 0, 4, 10, 20]}],
            1: [{"label": "human", "type": "mask", "encoded": "rle", "points": [0, 6, 2, 0, 5, 11, 21]}],
        }
    )
    assert mask[0][0]["track_id"] == mask[1][0]["track_id"]


def test_one_object_keeps_one_track():
    from app.detect import dedupe_shapes
    from app.service import to_cvat_tracks

    nested = dedupe_shapes([
        {"label": "car", "type": "rectangle", "points": [0, 0, 100, 60], "score": 0.9},
        {"label": "car", "type": "rectangle", "points": [12, 8, 70, 48], "score": 0.55},
        {"label": "car", "type": "rectangle", "points": [220, 10, 300, 70], "score": 0.8},
    ])
    assert len(nested) == 2
    linked = associate_by_iou(
        {
            0: [{"label": "car", "type": "rectangle", "points": [0, 0, 40, 40], "score": 0.9}],
            1: [
                {"label": "car", "type": "rectangle", "points": [10, 0, 50, 40], "score": 0.4},
                {"label": "car", "type": "rectangle", "points": [0, 0, 40, 40], "score": 0.95},
                {"label": "car", "type": "rectangle", "points": [4, 4, 36, 36], "score": 0.5},
            ],
            2: [{"label": "car", "type": "rectangle", "points": [2, 2, 42, 42], "score": 0.9}],
        }
    )
    ids = {shape["track_id"] for frame in linked.values() for shape in frame}
    assert ids == {linked[0][0]["track_id"]}
    assert len(linked[1]) == 1
    labels = {"car": {"id": 3, "name": "car", "attributes": []}}
    tracks = to_cvat_tracks({0: linked[0]}, labels, end_frame=6)
    assert tracks[0]["shapes"][-1]["outside"] is True
    assert tracks[0]["shapes"][-1]["frame"] == 1
    parked = to_cvat_tracks(
        {0: [{"label": "car", "type": "rectangle", "points": [0, 0, 10, 10], "track_id": 1, "frame": 0}]},
        labels,
        end_frame=0,
    )
    assert parked[0]["shapes"][-1]["outside"] is False


def test_object_that_leaves_the_frame_is_marked_outside():
    from app.service import to_cvat_tracks

    labels = {"car": {"id": 3, "name": "car", "attributes": []}}
    tracks = to_cvat_tracks(
        {
            0: [
                {"label": "car", "type": "rectangle", "points": [40, 20, 120, 80], "track_id": 1},
                {"label": "car", "type": "rectangle", "points": [0, 20, 80, 80], "track_id": 2},
            ],
            1: [
                {"label": "car", "type": "rectangle", "points": [150, 20, 199, 80], "track_id": 1},
                {"label": "car", "type": "rectangle", "points": [0, 20, 80, 80], "track_id": 2},
            ],
            2: [
                {"label": "car", "type": "rectangle", "points": [175, 30, 199, 55], "track_id": 1},
                {"label": "car", "type": "rectangle", "points": [0, 20, 80, 80], "track_id": 2},
            ],
        },
        labels,
        end_frame=2,
        frame_size=(200, 100),
    )
    leaving = next(track for track in tracks if any(shape["points"][0] == 40 for shape in track["shapes"]))
    parked_track = next(track for track in tracks if track is not leaving)
    assert [shape["outside"] for shape in leaving["shapes"]] == [False, False, True]
    assert all(shape["outside"] is False for shape in parked_track["shapes"])
    offscreen = to_cvat_tracks(
        {0: [{"label": "car", "type": "rectangle", "points": [-40, 10, 12, 50], "track_id": 1}]},
        labels,
        end_frame=0,
        frame_size=(200, 100),
    )
    assert offscreen[0]["shapes"][0]["outside"] is True


def test_fast_motion_and_a_gap_keep_the_same_track():
    from app.service import _min_assignment

    pairs = _min_assignment([[4, 1, 3], [2, 0, 5], [3, 2, 2]])
    assert sorted(pairs) == [(0, 1), (1, 0), (2, 2)]
    moving = {
        frame: [{"label": "car", "type": "rectangle", "points": [frame * 36, 10, frame * 36 + 40, 50], "score": 0.8}]
        for frame in range(10)
    }
    linked = associate_by_iou(moving)
    assert len({linked[frame][0]["track_id"] for frame in range(10)}) == 1
    assert linked[9][0]["track_status"] == "updated"
    hidden = {
        frame: [{"label": "car", "type": "rectangle", "points": [frame * 20, 0, frame * 20 + 40, 30], "score": 0.9}]
        for frame in (0, 1, 2, 3, 12)
    }
    recovered = associate_by_iou(hidden)
    assert recovered[0][0]["track_id"] == recovered[12][0]["track_id"]
    assert recovered[12][0]["track_status"] == "recovered"
    lanes = {}
    for frame in range(8):
        lanes[frame] = [
            {"label": "car", "type": "rectangle", "points": [frame * 30, 0, frame * 30 + 40, 24], "score": 0.9},
            {"label": "car", "type": "rectangle", "points": [220 - frame * 30, 50, 260 - frame * 30, 74], "score": 0.88},
        ]
    crossed = associate_by_iou(lanes)
    top = crossed[0][0]["track_id"]
    bottom = crossed[0][1]["track_id"]
    assert crossed[7][0]["track_id"] == top
    assert crossed[7][1]["track_id"] == bottom
    assert top != bottom


def test_parts_of_one_object_share_a_group():
    from app.segment import _mark_parts
    from app.service import associate_by_iou, to_cvat_tracks

    body = [10, 10, 110, 10, 110, 80, 10, 80]
    window = [30, 20, 70, 20, 70, 40, 30, 40]
    copy = [12, 12, 108, 12, 108, 78, 12, 78]
    marked = _mark_parts({"label": "car", "type": "polygon"}, [
        {"label": "car", "type": "polygon", "points": body},
        {"label": "car", "type": "polygon", "points": window},
        {"label": "car", "type": "polygon", "points": copy},
    ])
    assert len(marked) == 2
    assert marked[0]["primary"] is True
    assert marked[1]["primary"] is False

    def car(instance, points, primary, part):
        return {
            "label": "car", "type": "polygon", "points": points, "score": 0.9,
            "instance": instance, "primary": primary, "part_index": part,
        }

    frames = {}
    for frame in (0, 1):
        shift = frame * 15
        frames[frame] = [
            car("a", [p + (shift if i % 2 == 0 else 0) for i, p in enumerate(body)], True, 0),
            car("a", [p + (shift if i % 2 == 0 else 0) for i, p in enumerate(window)], False, 1),
            car("b", [200 + (shift if i % 2 == 0 else 0) for i, p in enumerate(body)], True, 0),
            {"label": "person", "type": "rectangle", "points": [0, 120, 24, 180], "score": 0.8},
        ]
    linked = associate_by_iou(frames)
    def groups(frame, instance):
        return {shape["group_id"] for shape in linked[frame] if shape.get("instance") == instance}

    assert groups(0, "a") == groups(1, "a")
    assert len(groups(0, "a")) == 1
    assert groups(0, "a") != groups(0, "b")
    person = next(shape for shape in linked[0] if shape["label"] == "person")
    assert person["group_id"] not in groups(0, "a")
    assert person["group_id"] not in groups(0, "b")
    labels = {"car": {"id": 4, "name": "car", "type": "rectangle", "attributes": []}}
    exported = []
    for shape in linked[0]:
        if shape.get("instance") != "a":
            continue
        exported.append({**shape, "type": "rectangle", "points": [10, 10, 40, 30]})
    tracks = to_cvat_tracks({0: exported}, labels)
    assert len(tracks) == 2
    assert {track["group"] for track in tracks} == groups(0, "a")


def test_a_track_keeps_its_label_when_one_frame_says_truck():
    frames = {}
    for frame in range(12):
        label = "truck" if frame == 5 else "car"
        frames[frame] = [{
            "label": label,
            "type": "rectangle",
            "points": [frame * 8, 10, frame * 8 + 40, 30],
            "score": 0.2 if frame == 5 else 0.86,
        }]
    linked = associate_by_iou(frames)
    assert len({linked[frame][0]["track_id"] for frame in range(12)}) == 1
    assert {linked[frame][0]["label"] for frame in range(12)} == {"car"}
    crowded = {
        0: [
            {"label": "car", "type": "rectangle", "points": [0, 0, 80, 40], "score": 0.9},
            {"label": "person", "type": "rectangle", "points": [20, 0, 40, 40], "score": 0.91},
        ]
    }
    pair = associate_by_iou(crowded)
    assert len(pair[0]) == 2
    assert {shape["label"] for shape in pair[0]} == {"car", "person"}
    jumped = {
        0: [{"label": "car", "type": "rectangle", "points": [0, 0, 40, 20], "score": 0.9}],
        1: [{"label": "car", "type": "rectangle", "points": [0, 0, 90, 50], "score": 0.2}],
    }
    drift = associate_by_iou(jumped)
    assert drift[1][0]["track_id"] == drift[0][0]["track_id"]
    assert drift[1][0]["outside"] is True


def test_corrections_keep_the_track_and_reject_a_drifted_frame():
    from app.learning import classify_frame, correction_summary
    from app.service import carry_track_corrections, stabilize_tracks

    snapshot = [{"label": "car", "type": "polygon", "points": [0, 0, 30, 0, 30, 20, 0, 20], "track_id": 7, "score": 0.8}]
    corrected = [{"label": "car", "type": "polygon", "points": [80, 40, 120, 40, 120, 70, 80, 70], "track_id": 7, "source": "manual"}]
    samples = classify_frame(snapshot, corrected)
    assert samples[0]["role"] == "correction"
    assert samples[0]["correction_type"] == "polygon_edit"
    assert samples[0]["track_id"] == 7
    assert samples[0]["boundary"] == "under"
    assert samples[0]["model_version"] == "yolo-sam-rules"
    summary = correction_summary([{"items": samples}], 3)
    assert summary["corrected"] == 1
    assert summary["segmentation_corrections"] == 1
    assert "not replaced" in summary["training_status"]

    annotations = {
        "version": 1,
        "tags": [],
        "shapes": [],
        "tracks": [{
            "label_id": 4,
            "frame": 0,
            "source": "auto",
            "shapes": [
                {"type": "rectangle", "frame": 0, "points": [0, 0, 20, 10]},
                {"type": "rectangle", "frame": 1, "points": [10, 0, 40, 10]},
                {"type": "rectangle", "frame": 2, "points": [20, 0, 40, 10]},
            ],
        }],
    }
    snapshots = {
        0: [{"label": "car", "type": "rectangle", "points": [0, 0, 20, 10], "track_id": 3}],
        1: [{"label": "car", "type": "rectangle", "points": [0, 0, 20, 10], "track_id": 3}],
        2: [{"label": "car", "type": "rectangle", "points": [20, 0, 40, 10], "track_id": 3}],
    }
    carried = carry_track_corrections(annotations, snapshots)
    assert carried is not None
    later = carried["tracks"][0]["shapes"][2]["points"]
    assert later == [35, 0, 55, 10]

    frames = {
        0: [{"label": "car", "type": "rectangle", "points": [0, 0, 40, 20], "track_id": 1, "track_confidence": 0.9}],
        1: [{"label": "car", "type": "rectangle", "points": [10, 0, 50, 20], "track_id": 1, "track_confidence": 0.9}],
        2: [{"label": "car", "type": "rectangle", "points": [20, 0, 60, 20], "track_id": 1, "track_confidence": 0.9}],
        3: [{"label": "car", "type": "rectangle", "points": [400, 0, 440, 20], "track_id": 1, "track_confidence": 0.2}],
    }
    stable = stabilize_tracks(frames, (640, 480))
    assert stable[3][0]["outside"] is True
    assert stable[2][0].get("outside") is not True
    outside = stabilize_tracks(
        {0: [{"label": "car", "type": "rectangle", "points": [-80, 0, -10, 20], "track_id": 1, "track_confidence": 0.9}]},
        (200, 100),
    )
    assert outside[0][0]["outside"] is True


def test_drifted_frame_is_redrawn_on_the_same_track():
    from app.service import recover_drifted

    frames = {
        0: [{"label": "car", "type": "polygon", "points": [0, 0, 40, 0, 40, 20, 0, 20], "track_id": 1}],
        1: [{
            "label": "car",
            "type": "polygon",
            "points": [300, 0, 340, 0, 340, 20, 300, 20],
            "track_id": 1,
            "outside": True,
            "review": "This frame drifted off the object, so it was not drawn. Check it.",
            "track_confidence": 0.2,
        }],
    }

    def trace(image, shapes):
        assert image == b"frame"
        assert shapes[0]["points"] == [0, 0, 40, 20]
        return {0: [{"type": "polygon", "points": [4, 0, 44, 0, 44, 22, 4, 22], "label": "car"}]}

    recover_drifted(frames, lambda frame: b"frame", trace)
    assert frames[1][0]["outside"] is False
    assert frames[1][0]["track_id"] == 1
    assert frames[1][0]["points"][0] == 4
    assert "review" not in frames[1][0]


def test_review_flags_and_self_crossing_and_tracks():
    bowtie = [0, 0, 10, 10, 0, 10, 10, 0]
    assert crosses_self(bowtie)
    reasons = review_reasons(
        {"label": "pothole", "type": "polygon", "points": bowtie, "attributes": {"severity": "huge"}, "score": 0.1},
        {"rules": []},
        {"name": "pothole", "attributes": [{"name": "severity", "values": ["low", "high"]}]},
    )
    assert any("allowed" in reason for reason in reasons)
    assert any("crosses" in reason for reason in reasons)
    linked = associate_by_iou(
        {
            0: [{"label": "car", "type": "rectangle", "points": [0, 0, 10, 10]}],
            1: [{"label": "car", "type": "rectangle", "points": [1, 1, 11, 11]}],
        }
    )
    assert linked[0][0]["track_id"] == linked[1][0]["track_id"]
    assert resample_polygon([0, 0, 10, 0, 10, 10, 0, 10], 4)


class FakeCvat:
    def __init__(self):
        self.labels = []
        self.issues = []
        self.shapes = []
        self.jobs = [
            {
                "id": 3,
                "task_id": 7,
                "project_id": 1,
                "start_frame": 0,
                "stop_frame": 1,
                "state": "completed",
                "stage": "annotation",
                "updated_date": "2026-01-01T00:00:00Z",
            }
        ]
        self.annotations = {"shapes": [], "tracks": [], "tags": []}
        self.job_updates = []
        self.webhooks = []

    def close(self):
        return None

    def get_project(self, project_id):
        if project_id == 99:
            raise CvatError(403, "forbidden")
        if project_id != 1:
            raise CvatError(404, "missing")
        return {"id": 1, "name": "road"}

    def get_labels(self, project_id):
        return list(self.labels)

    def patch_project_labels(self, project_id, labels):
        for label in labels:
            self.labels.append({**label, "id": len(self.labels) + 1, "attributes": [
                {**attr, "id": index + 1} for index, attr in enumerate(label.get("attributes") or [])
            ]})
        return {}

    def get_task(self, task_id):
        return {"id": task_id, "project_id": 1, "name": "batch", "size": 2, "mode": "annotation"}

    def get_task_meta(self, task_id):
        return {"frames": [{"width": 100, "height": 80, "name": "a.jpg"}, {"width": 100, "height": 80, "name": "b.jpg"}]}

    def get_jobs(self, task_id=None, project_id=None):
        return list(self.jobs)

    def get_annotations(self, kind, resource_id):
        return self.annotations

    def put_annotations(self, kind, resource_id, payload):
        self.shapes = list(payload["shapes"])

    def create_annotations(self, kind, resource_id, payload):
        self.shapes.extend(payload["shapes"])

    def update_job(self, job_id, payload):
        self.job_updates.append(payload)

    def clear_review_issues(self, job_id):
        before = len(self.issues)
        self.issues = [item for item in self.issues if item.get("job") != job_id or not str(item.get("message") or "").startswith("Review first:")]
        return before - len(self.issues)

    def create_webhook(self, project_id, target_url, secret, events):
        self.webhooks.append(target_url)
        return {"id": 5}

    def get_frame(self, task_id, frame):
        return b""


def _client(tmp_path: Path):
    app = create_app(
        Settings(
            database_url=f"sqlite:///{tmp_path / 'test.sqlite3'}",
            analyzer_data_dir=str(tmp_path),
            webhook_secret="test-secret",
            cvat_base_url="http://cvat.invalid",
            analyzer_webhook_url="http://analyzer:8090/webhooks/cvat",
        )
    )
    fake = FakeCvat()

    def identity():
        return {"scheme": "Bearer", "token": "user", "organization": ""}

    def cvat_client():
        yield fake

    app.dependency_overrides[app.state.identity] = identity
    app.dependency_overrides[app.state.cvat_client] = cvat_client
    return TestClient(app), fake


def test_api_apply_is_idempotent_and_permissions_fail(tmp_path):
    client, fake = _client(tmp_path)
    uploaded = client.post(
        "/projects/1/requirements",
        files={"file": ("req.txt", DOCUMENT.encode("utf-8"), "text/plain")},
        headers={"Authorization": "Bearer user"},
    )
    assert uploaded.status_code == 200, uploaded.text
    applied = client.post(
        "/projects/1/labels/apply",
        json={"confirm_type_changes": False},
        headers={"Authorization": "Bearer user"},
    )
    assert applied.status_code == 200, applied.text
    assert {label["name"] for label in fake.labels} == {"pothole", "car"}
    second = client.post(
        "/projects/1/labels/apply",
        json={"confirm_type_changes": False},
        headers={"Authorization": "Bearer user"},
    )
    assert second.json()["applied"] == 0
    denied = client.get("/projects/99/spec", headers={"Authorization": "Bearer user"})
    assert denied.status_code == 403
    bare = create_app(
        Settings(
            database_url=f"sqlite:///{tmp_path / 'auth.sqlite3'}",
            analyzer_data_dir=str(tmp_path),
            webhook_secret="test-secret",
        )
    )
    assert TestClient(bare).get("/projects/1/spec").status_code == 401


def test_image_edits_are_learned_without_a_comment(tmp_path):
    client, fake = _client(tmp_path)
    headers = {"Authorization": "Bearer user"}
    client.post("/projects/1/requirements", files={"file": ("req.txt", DOCUMENT.encode(), "text/plain")}, headers=headers)
    client.post("/projects/1/labels/apply", json={"confirm_type_changes": False}, headers=headers)
    client.post("/projects/1/learning/settings", json={"annotation_mode": "mixed", "learn_enabled": True}, headers=headers)
    fake.jobs[0]["state"] = "annotation"
    label_id = next(item["id"] for item in fake.labels if item["name"] == "car")
    fake.annotations = {
        "shapes": [{
            "id": 11, "frame": 0, "label_id": label_id, "type": "rectangle",
            "points": [1, 1, 20, 10], "source": "manual", "attributes": [],
        }],
        "tracks": [],
        "tags": [],
    }
    assert client.post("/projects/1/sync", headers=headers).status_code == 200
    fake.annotations["shapes"][0]["points"] = [21, 11, 40, 20]
    assert client.post("/projects/1/sync", headers=headers).status_code == 200
    from sqlalchemy import select
    from app.db import Sample

    session = client.app.state.sessions()
    row = session.scalar(select(Sample).where(Sample.job_id == 3, Sample.frame == 0))
    assert row is not None
    assert any(item["role"] == "correction" and item["correction_type"] == "move" for item in row.items_json)
    assert fake.issues == []


def test_webhook_signature_duplicate_and_both_modes(tmp_path):
    client, fake = _client(tmp_path)
    headers = {"Authorization": "Bearer user"}
    client.post("/projects/1/requirements", files={"file": ("req.txt", DOCUMENT.encode(), "text/plain")}, headers=headers)
    client.post("/projects/1/labels/apply", json={"confirm_type_changes": False}, headers=headers)
    client.post("/projects/1/learning/settings", json={"annotation_mode": "human_first", "learn_enabled": True}, headers=headers)
    fake.annotations = {
        "shapes": [
            {
                "frame": 0,
                "label_id": fake.labels[1]["id"],
                "type": "rectangle",
                "points": [1, 1, 20, 10],
                "source": "manual",
                "attributes": [],
            }
        ],
        "tracks": [],
        "tags": [],
    }
    payload = {
        "event": "update:job",
        "webhook_id": 5,
        "job": {"id": 3, "task_id": 7, "project_id": 1, "state": "completed", "updated_date": "t1", "start_frame": 0},
    }
    raw = json.dumps(payload).encode()
    signature = "sha256=" + hmac.new(b"test-secret", raw, hashlib.sha256).hexdigest()
    bad = client.post("/webhooks/cvat", content=raw, headers={"X-Signature-256": "sha256=nope"})
    assert bad.status_code == 401
    # No service token: the event is stored and not treated as a person's drawing yet.
    stored = client.post("/webhooks/cvat", content=raw, headers={"X-Signature-256": signature})
    assert stored.status_code == 200
    assert stored.json()["status"] in {"stored", "learned"}
    duplicate = client.post("/webhooks/cvat", content=raw, headers={"X-Signature-256": signature})
    assert duplicate.json()["status"] == "duplicate"

    learned = client.post("/projects/1/sync", headers=headers)
    assert learned.status_code == 200
    assert learned.json()["samples"] == 1

    def detect(frame, labels):
        return [{"label": "car", "type": "rectangle", "points": [0, 0, 30, 20], "score": 0.8, "attributes": {}}]

    from app.main import run_annotation
    from app.db import Run
    from app.service import get_project

    session = client.app.state.sessions()
    state = get_project(session, 1)
    # Give the profile something to apply by recording enough corrections through the API samples.
    run = Run(cvat_project_id=1, task_id=7, status="running", mode="auto_first", profile_version=state.profile_version)
    session.add(run)
    session.flush()
    summary = run_annotation(session, fake, state, 7, run, client.app.state.settings, detect=detect)
    session.commit()
    session.close()
    assert summary["written"] == 1
    autos = [shape for shape in fake.shapes if shape["source"] == "auto"]
    manuals = [shape for shape in fake.shapes if shape["source"] == "manual"]
    assert len(autos) == 1
    assert len(manuals) == 1
    assert autos[0]["label_id"] == fake.labels[1]["id"]
    assert fake.job_updates == []


def test_chat_can_revise_requirement_labels_and_delete_a_task():
    from app.chat import revise_spec, run_tool

    parsed = {
        "labels": [
            {"name": "standing", "type": "skeleton"},
            {"name": "person", "type": "skeleton"},
            {"name": "person_bbox", "type": "rectangle"},
        ]
    }
    removed = revise_spec(parsed, remove=["standing"])
    assert [item["name"] for item in removed["labels"]] == ["person", "person_bbox"]
    kept = revise_spec(parsed, keep=["person"])
    assert [item["name"] for item in kept["labels"]] == ["person"]

    class Tasks:
        def __init__(self):
            self.deleted = []

        def get_task(self, task_id):
            return {"id": task_id, "project_id": 6, "name": "task"}

        def delete_task(self, task_id):
            self.deleted.append(task_id)

    client = Tasks()
    result = run_tool("delete_task", {"project_id": 6, "task_id": 14}, client, None, None, {})
    assert client.deleted == [14]
    assert "14" in result


def test_chat_agent_creates_a_project_for_the_signed_in_user():
    from app.chat import run_tool

    class Projects:
        def __init__(self):
            self.created = []

        def list_projects(self):
            return [{"id": 2, "name": "road"}]

        def create_project(self, name):
            self.created.append(name)
            return {"id": 9, "name": name}

    client = Projects()
    listed = run_tool("list_projects", {}, client, None, None, {})
    assert "road" in listed
    created = run_tool("create_project", {"name": "Night defects"}, client, None, None, {})
    assert client.created == ["Night defects"]
    assert "/projects/9" in created


def test_modes_are_both_visible_in_learning_panel(tmp_path):
    client, _fake = _client(tmp_path)
    headers = {"Authorization": "Bearer user"}
    client.post("/projects/1/learning/settings", json={"annotation_mode": "auto_first"}, headers=headers)
    view = client.get("/projects/1/learning", headers=headers)
    assert view.json()["mode_text"] == "The agent annotates first, you correct"
    client.post("/projects/1/learning/settings", json={"annotation_mode": "human_first"}, headers=headers)
    view = client.get("/projects/1/learning", headers=headers)
    assert view.json()["mode_text"] == "You annotate, the agent learns"
    forgotten = client.post("/projects/1/learning/reset", headers=headers)
    assert forgotten.json()["summary"] == "The agent has learned from 0 finished frames."


def test_vision_shapes_and_correction_lessons():
    from app.learning import prompt_lessons
    from app.vision import parse_shapes

    labels = [
        {"name": "vehicle", "type": "rectangle", "detect_as": ["car"], "min_size": 20, "attributes": []},
        {"name": "road_defect", "type": "polygon", "attributes": []},
    ]
    text = json.dumps(
        {
            "shapes": [
                {"label": "car", "type": "bbox", "points": [10, 10, 40, 40], "attributes": {"color": "white"}},
                {"label": "road_defect", "type": "polygon", "points": [1, 2, 3, 4, 5, 6], "attributes": {"severity": "medium"}},
                {"label": "person", "type": "rectangle", "points": [0, 0, 9, 9]},
                {"label": "vehicle", "type": "rectangle", "points": [0, 0, 5, 5]},
            ]
        }
    )
    reference = json.dumps(
        {
            "objects": [
                {"label": "vehicle", "bbox": [10, 10, 40, 40], "score": 0.9, "attributes": {"color": "white"}},
                {"label": "road_defect", "polygon": [[1, 2], [30, 2], [30, 40], [1, 40]]},
            ]
        }
    )
    referenced = parse_shapes(reference, labels, scale=2, width=100, height=80)
    assert referenced[0]["type"] == "rectangle" and referenced[0]["points"] == [20, 20, 80, 80]
    assert referenced[1]["type"] == "polygon" and referenced[1]["points"][0] == 2
    from app.vision import _coarse_polygons
    assert _coarse_polygons([{"type": "polygon", "points": [0, 0, 1, 0, 1, 1, 0, 1, 2, 2, 3, 3]}])
    assert not _coarse_polygons([{"type": "polygon", "points": list(range(16))}])
    shapes = parse_shapes(text, labels, scale=2, width=100, height=80)
    assert [item["label"] for item in shapes] == ["vehicle", "road_defect"]
    messy = parse_shapes('{"shapes":["vehicle", {"label":"road_defect","type":"polygon","points":[[1,2],[3,4],[5,6]]}]}', labels, 1, 100, 80)
    assert messy[0]["label"] == "road_defect" and messy[0]["type"] == "polygon"
    assert shapes[0]["points"] == [20, 20, 80, 80]
    assert shapes[1]["type"] == "polygon"
    lessons = prompt_lessons(
        {"rules": []},
        [
            {
                "items": [
                    {
                        "role": "correction",
                        "agent": {"label": "vehicle", "type": "rectangle", "points": [0, 0, 10, 10], "attributes": {}},
                        "human": {"label": "road_defect", "type": "polygon", "points": [0, 0, 10, 0, 10, 10], "attributes": {}},
                    }
                ]
            }
        ],
    )
    assert not any("road_defect" in line for line in lessons)
    skeleton = parse_shapes(
        json.dumps({
            "objects": [{
                "label": "person",
                "keypoints": [
                    {"name": "nose", "x": 10, "y": 12, "v": 2},
                    {"name": "left_shoulder", "x": 8, "y": 20, "v": 1},
                    {"name": "right_shoulder", "x": 0, "y": 0, "v": 0},
                ],
            }]
        }),
        [{"name": "person", "type": "skeleton", "keypoints": ["nose", "left_shoulder", "right_shoulder"]}],
        scale=2,
        width=100,
        height=80,
    )
    assert skeleton[0]["type"] == "skeleton"
    assert skeleton[0]["elements"][0]["points"] == [20, 24]
    assert skeleton[0]["elements"][2]["outside"] is True
    from app.service import to_cvat_shape
    written = to_cvat_shape(
        skeleton[0],
        {"person": {"id": 3, "name": "person", "sublabels": [
            {"id": 4, "name": "nose"},
            {"id": 5, "name": "left_shoulder"},
            {"id": 6, "name": "right_shoulder"},
        ], "attributes": []}},
        0,
    )
    assert written["type"] == "skeleton" and written["points"] == []
    assert [item["label_id"] for item in written["elements"]] == [4, 5, 6]
    assert written["elements"][2]["outside"] is True


def test_project_steps_and_clearing_a_wrong_label():
    from app.chat import run_tool
    from app.report import extra_label_deletions, requirement_steps

    spec = {
        "output_format": "YOLO",
        "labels": [{"name": "person", "type": "skeleton", "keypoints": ["nose"]}],
        "guide": {"summary": "Mark each person.", "decisions": [{"name": "person", "how_to_annotate": "Place the nose."}]},
    }
    steps = requirement_steps(spec)
    assert steps[0]["title"] == "Requirement"
    assert any("person" in step["title"] for step in steps)
    assert steps[-1]["title"] == "Export"
    existing = [
        {"id": 1, "name": "person", "type": "skeleton"},
        {"id": 2, "name": "person", "type": "skeleton"},
        {"id": 3, "name": "vehicle", "type": "rectangle"},
        {"id": 4, "name": "nose", "parent_id": 2},
    ]
    removed = extra_label_deletions(spec, existing)
    assert {item["id"] for item in removed} == {2, 3, 4}

    class Project:
        def __init__(self):
            self.cleared = []

        def get_task(self, task_id):
            return {"id": task_id, "project_id": 4}

        def get_jobs(self, task_id=None):
            return [{"id": 8}]

        def get_annotations(self, kind, resource_id):
            return {"version": 1, "tags": [], "shapes": [{"id": 1}, {"id": 2}], "tracks": []}

        def put_annotations(self, kind, resource_id, payload):
            self.cleared.append(payload["shapes"])

    project = Project()
    result = run_tool("clear_annotations", {"project_id": 4, "task_id": 14}, project, None, None, {})
    assert project.cleared == [[]]
    assert "2" in result


def test_requirement_export_format():
    from app.exporting import build_archive, export_kind
    import io
    import zipfile

    parsed = extract_spec("Export format: YOLO v8 detection\n\nLabel: vehicle\nType: rectangle\n")
    assert parsed["output_format"].lower().startswith("yolo")
    assert export_kind(parsed["output_format"]) == "yolo"
    assert export_kind("CVAT") == ""
    assert export_kind("COCO keypoints") == "coco"
    assert export_kind("LabelMe") == "labelme"
    assert export_kind("the client delivery pack") == "client"
    spoken = extract_spec("Please export the annotations in COCO format.\n\nLabel: car\nType: rectangle\n")
    assert spoken["output_format"].lower().startswith("coco")
    from app.chat import revise_spec
    saved = revise_spec(spoken, output_format="YOLO pose")
    assert saved["output_format"] == "YOLO pose"
    blob = build_archive(
        "yolo",
        "YOLO v8 detection",
        ["vehicle", "road_defect"],
        [{
            "name": "road.jpg",
            "width": 100,
            "height": 50,
            "shapes": [{"label": "vehicle", "type": "rectangle", "points": [10, 10, 30, 40]}],
        }],
    )
    with zipfile.ZipFile(io.BytesIO(blob)) as archive:
        line = archive.read("labels/road.txt").decode().split()
        classes = archive.read("classes.txt").decode().splitlines()
    assert classes == ["vehicle", "road_defect"]
    assert line[0] == "0"
    assert line[1] == "0.200000"
    assert line[2] == "0.500000"
    pose = build_archive(
        "yolo-pose",
        "YOLO pose",
        ["person"],
        [{
            "name": "person.jpg",
            "width": 100,
            "height": 100,
            "shapes": [{
                "label": "person",
                "type": "skeleton",
                "points": [],
                "keypoint_order": ["nose", "left_shoulder"],
                "elements": [
                    {"name": "nose", "points": [40, 20], "outside": False, "occluded": False},
                    {"name": "left_shoulder", "points": [0, 0], "outside": True, "occluded": False},
                ],
            }],
        }],
    )
    with zipfile.ZipFile(io.BytesIO(pose)) as archive:
        pose_line = archive.read("labels/person.txt").decode().split()
    assert pose_line[-1] == "0"
    assert pose_line[-4] == "2"


def test_image_upload_waits_for_cvat_import(monkeypatch):
    calls = []

    class FakeResponse:
        def __init__(self, status, payload):
            self.status_code = status
            self.content = json.dumps(payload).encode()
            self.text = self.content.decode()

        def json(self):
            return json.loads(self.content)

    class FakeClient:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

        def request(self, method, path, **kwargs):
            calls.append((method, path, kwargs.get("headers") or {}, kwargs.get("files"), kwargs.get("json")))
            if kwargs.get("headers", {}).get("Upload-Finish"):
                return FakeResponse(202, {"rq_id": "import-1"})
            if path == "/api/requests/import-1":
                return FakeResponse(200, {"status": "finished", "message": ""})
            if path == "/api/tasks/7":
                return FakeResponse(200, {"id": 7, "size": 2})
            return FakeResponse(202, {})

        def close(self):
            return None

    monkeypatch.setattr("app.cvat.httpx.Client", FakeClient)
    from app.cvat import CvatClient

    CvatClient("http://cvat", "token").upload_task_images(7, [("road.jpg", b"jpeg"), ("lane.jpg", b"jpeg")])
    headers = [item[2] for item in calls if item[1].endswith("/data")]
    assert {"Upload-Start": "true"} in [{key: value} for header in headers for key, value in header.items() if key.startswith("Upload-")] or any(
        header.get("Upload-Start") == "true" for header in headers
    )
    assert any(header.get("Upload-Multiple") == "true" for header in headers)
    assert any(header.get("Upload-Finish") == "true" for header in headers)
    uploaded = next(item[3] for item in calls if item[2].get("Upload-Multiple"))
    assert uploaded[0][0] == "client_files[0]"
    assert uploaded[1][0] == "client_files[1]"
    assert any(item[1] == "/api/requests/import-1" for item in calls)
    finish = next(item for item in calls if item[2].get("Upload-Finish"))
    assert finish[4]["image_quality"] == 70
    assert "use_zip_chunks" not in finish[4]


def test_video_upload_asks_cvat_to_decode_frames(monkeypatch):
    calls = []

    class FakeResponse:
        def __init__(self, status, payload):
            self.status_code = status
            self.content = json.dumps(payload).encode()
            self.text = self.content.decode()

        def json(self):
            return json.loads(self.content)

    class FakeClient:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

        def request(self, method, path, **kwargs):
            calls.append((method, path, kwargs.get("headers") or {}, kwargs.get("files"), kwargs.get("json")))
            if kwargs.get("headers", {}).get("Upload-Finish"):
                return FakeResponse(202, {"rq_id": "import-2"})
            if path == "/api/requests/import-2":
                return FakeResponse(200, {"status": "finished", "message": ""})
            if path == "/api/tasks/8":
                return FakeResponse(200, {"id": 8, "size": 120, "mode": "interpolation"})
            return FakeResponse(202, {})

        def close(self):
            return None

    monkeypatch.setattr("app.cvat.httpx.Client", FakeClient)
    from app.cvat import CvatClient

    CvatClient("http://cvat", "token").upload_task_images(8, [("clip.mp4", b"video")])
    finish = next(item for item in calls if item[2].get("Upload-Finish"))
    assert finish[4]["use_zip_chunks"] is True
    assert finish[4]["use_cache"] is True
    uploaded = next(item[3] for item in calls if item[2].get("Upload-Multiple"))
    assert uploaded[0][1][2] == "video/mp4"


def test_chat_keeps_an_attached_video(tmp_path):
    from app.chat import read_upload

    bundle = read_upload([("street.mp4", b"video")], tmp_path)
    assert bundle["images"] == [("street.mp4", b"video")]


def test_chat_shows_the_model_error_and_skips_a_missing_model():
    from app.chat import _anthropic_message, _model_unavailable

    class Reply:
        status_code = 400
        text = '{"error":{"type":"invalid_request_error","message":"Your credit balance is too low to access the Anthropic API."}}'

        def json(self):
            return {"error": {"type": "invalid_request_error", "message": "Your credit balance is too low to access the Anthropic API."}}

    message = _anthropic_message(Reply())
    assert "credit balance" in message
    assert not _model_unavailable(400, message)
    assert _model_unavailable(400, "model: claude-sonnet-5-5 not found")
    assert _model_unavailable(404, "")


EXAMPLE = {
    "dataset": {"name": "human_segmentation", "schema_version": "1.0"},
    "images": [
        {
            "image_name": "image_001.jpg",
            "width": 1920,
            "height": 1080,
            "objects": [
                {
                    "object_id": "person_001",
                    "class_name": "person",
                    "annotation_type": "polygon",
                    "segmentation": [[120, 80], [150, 75], [175, 100], [160, 180], [130, 190]],
                    "attributes": {"occluded": False},
                }
            ],
        }
    ],
}


def test_client_example_converts_polygon_and_keeps_structure():
    from app.custom_format import analyze_files, convert_dataset

    profile = analyze_files([("client.json", json.dumps(EXAMPLE).encode())])
    assert profile["ready"]
    assert any("inferred" in note.lower() or "review" in note.lower() for note in profile["ambiguities"])
    images = [{
        "name": "frame.jpg",
        "width": 1920,
        "height": 1080,
        "shapes": [{
            "id": 7,
            "label": "person",
            "type": "polygon",
            "points": [120, 80, 150, 75, 175, 100, 160, 180, 130, 190],
            "attributes": {"occluded": False},
        }],
    }]
    document, report = convert_dataset(profile, "road", images)
    assert report["errors"] == []
    assert document["dataset"]["name"] == "road"
    assert document["dataset"]["schema_version"] == "1.0"
    obj = document["images"][0]["objects"][0]
    assert document["images"][0]["image_name"] == "frame.jpg"
    assert obj["class_name"] == "person"
    assert obj["segmentation"][0] == [120, 80]
    assert obj["object_id"] == "person_001"


def test_client_format_blocks_masks_and_rejects_malformed_or_schema_only_input():
    from app.custom_format import analyze_files, package

    profile = analyze_files([("client.json", json.dumps(EXAMPLE).encode())])
    blob, report = package(profile, "road", [{
        "name": "frame.jpg",
        "width": 100,
        "height": 80,
        "shapes": [{"label": "person", "type": "mask", "points": []}],
    }])
    assert blob is None
    assert any("mask" in error.lower() for error in report["errors"])
    broken = analyze_files([("bad.json", b"{")])
    assert broken["ready"] is False
    schema = analyze_files([("spec.json", json.dumps({"$schema": "https://json-schema.org/draft/2020-12/schema", "type": "object", "properties": {"images": {"type": "array"}}}).encode())])
    assert schema["ready"] is False
    assert schema["ambiguities"]


def test_client_format_flags_normalized_text_that_disagrees_with_the_example():
    from app.custom_format import analyze_files

    text = "Use normalized coordinates between 0 and 1.\n" + json.dumps(EXAMPLE)
    profile = analyze_files([("notes.txt", text.encode())])
    assert profile["ready"]
    assert profile["coordinates"] == "pixel"
    assert any("pixel" in note.lower() for note in profile["ambiguities"])


def test_custom_format_export_downloads_zip_and_hides_other_organizations(tmp_path):
    client, fake = _client(tmp_path)
    fake.labels = [{"id": 1, "name": "person", "type": "polygon"}]
    fake.annotations = {
        "shapes": [{
            "id": 4,
            "frame": 0,
            "label_id": 1,
            "type": "polygon",
            "points": [1, 2, 3, 4, 5, 6],
            "occluded": False,
            "source": "manual",
            "attributes": [],
        }],
        "tracks": [],
        "tags": [],
    }
    analyzed = client.post(
        "/projects/1/custom-format/analyze",
        files=[("files", ("client.json", json.dumps(EXAMPLE).encode(), "application/json"))],
        headers={"Authorization": "Bearer user"},
    )
    assert analyzed.status_code == 200, analyzed.text
    profile = analyzed.json()["profile"]
    exported = client.post(
        "/projects/1/custom-format/export",
        json={"profile": profile, "save": True, "task_id": 7, "preview": False},
        headers={"Authorization": "Bearer user"},
    )
    assert exported.status_code == 200, exported.text
    assert exported.headers["content-type"].startswith("application/zip")
    missing = client.post(
        "/projects/1/custom-format/export",
        json={"profile_id": 999, "task_id": 7},
        headers={"Authorization": "Bearer user"},
    )
    assert missing.status_code == 404
    saved = client.get("/projects/1/custom-format/profiles", headers={"Authorization": "Bearer user"})
    assert saved.json()["profiles"]


ROAD_REQUIREMENT = """
Format: JSON
Delivery folder structure
annotations/instances_batch_001.json
images/
{
  "images": [{"id": 1, "file_name": "image_0001.jpg", "width": 1280, "height": 720}],
  "categories": [{"id": 1, "name": "vehicle"}, {"id": 2, "name": "road_defect"}],
  "annotations": [
    {"id": 1, "image_id": 1, "category_id": 1, "class_id": 1, "bbox": [320, 210, 260, 170], "box_xywh": [320, 210, 260, 170], "area": 44200, "iscrowd": 0, "attributes": {"color": "white"}, "track_id": "clip_001_vehicle_01"},
    {"id": 2, "image_id": 1, "category_id": 2, "class_id": 2, "segmentation": [[610, 520, 660, 505, 700, 530]], "area": 0, "iscrowd": 0, "attributes": {"severity": "medium"}}
  ]
}
"""


def test_saved_requirement_sets_json_folder_and_blocks_a_bad_shape(tmp_path):
    import io
    import zipfile
    from app.custom_format import analyze_files, package

    profile = analyze_files([("requirement.txt", ROAD_REQUIREMENT.encode())])
    assert profile["ready"]
    assert profile["container"] == "json"
    assert profile["annotation_file"] == "annotations/instances_batch_001.json"
    assert profile["images_dir"] == "images"
    images = [
        {
            "name": "frame.jpg",
            "width": 1280,
            "height": 720,
            "shapes": [
                {"label": "vehicle", "type": "rectangle", "points": [10, 20, 30, 50], "attributes": {"color": "white"}, "track_id": "v1"},
                {"label": "road_defect", "type": "polygon", "points": [1, 2, 3, 2, 3, 4], "attributes": {"severity": "low"}},
            ],
        }
    ]
    blob, report = package(profile, "road", images)
    assert report["errors"] == [], report
    with zipfile.ZipFile(io.BytesIO(blob)) as archive:
        document = json.loads(archive.read("annotations/instances_batch_001.json"))
    assert document["annotations"][0]["bbox"] == [10, 20, 20, 30]
    assert document["annotations"][0]["class_id"] == 1
    assert document["annotations"][1]["segmentation"][0][:2] == [1, 2]
    blocked, blocked_report = package(profile, "road", [{
        "name": "frame.jpg",
        "width": 100,
        "height": 80,
        "shapes": [{"label": "vehicle", "type": "mask", "points": []}],
    }])
    assert blocked is None
    assert blocked_report["errors"]


def test_video_track_fills_the_frames_between_keyframes():
    from app.main import _spread_track

    track = {
        "id": 9,
        "label_id": 3,
        "shapes": [
            {"frame": 0, "type": "rectangle", "points": [0, 0, 10, 10], "outside": False},
            {"frame": 2, "type": "rectangle", "points": [20, 0, 30, 10], "outside": False},
            {"frame": 4, "type": "rectangle", "points": [20, 0, 30, 10], "outside": True},
        ],
    }
    placed = dict(_spread_track(track, 0, 6))
    assert set(placed) == {0, 1, 2, 3}
    assert placed[1]["points"] == [10.0, 0.0, 20.0, 10.0]
    assert placed[1]["track_id"] == 9
    assert placed[3]["points"] == [20, 0, 30, 10]


def test_requirement_on_the_project_is_used_for_export(tmp_path):
    import io
    import zipfile

    folder = tmp_path / "uploads" / "1"
    folder.mkdir(parents=True)
    (folder / "requirement.txt").write_text(ROAD_REQUIREMENT, encoding="utf-8")
    client, fake = _client(tmp_path)
    fake.labels = [{"id": 1, "name": "vehicle", "type": "rectangle"}]
    fake.annotations = {
        "shapes": [{
            "id": 4,
            "frame": 0,
            "label_id": 1,
            "type": "rectangle",
            "points": [10, 20, 30, 50],
            "occluded": False,
            "source": "manual",
            "attributes": [{"name": "color", "value": "white"}],
            "track_id": "v1",
        }],
        "tracks": [],
        "tags": [],
    }
    exported = client.get("/projects/1/export?task_id=7", headers={"Authorization": "Bearer user"})
    assert exported.status_code == 200, exported.text
    with zipfile.ZipFile(io.BytesIO(exported.content)) as archive:
        assert "annotations/instances_batch_001.json" in archive.namelist()
        document = json.loads(archive.read("annotations/instances_batch_001.json"))
    assert document["images"][0]["file_name"] == "a.jpg"
    assert document["annotations"][0]["attributes"]["color"] == "white"


HSEG_REQUIREMENT = """
human_segmentation_export/
manifest.hseg.json
images/
masks/
{
  "format": "HSEG",
  "format_version": "1.0",
  "project": {"project_key": "human_segmentation", "label_set": [{"label_key": "human", "display_name": "Human"}]},
  "assets": [{
    "asset_key": "scene_0001",
    "source_file": "images/scene_0001.jpg",
    "image_size": {"width_px": 1280, "height_px": 720},
    "instances": [{
      "instance_key": "scene_0001_human_0001",
      "label_key": "human",
      "geometry": {"kind": "polygon", "coordinate_space": "image_pixels_top_left", "vertices": [[10, 10], [40, 10], [40, 40], [10, 40]]},
      "mask_file": "masks/scene_0001/human_0001.png",
      "visible_region_only": true,
      "attributes": {"occlusion_level": "partial", "truncated_by_image_edge": false},
      "annotation_state": "review_required"
    }]
  }]
}
"""


def test_hseg_example_builds_manifest_and_mask():
    import io
    import zipfile
    from app.custom_format import analyze_files, package

    profile = analyze_files([("hseg.txt", HSEG_REQUIREMENT.encode())])
    assert profile["ready"]
    assert profile["layout"] == "hseg"
    assert profile["annotation_file"] == "human_segmentation_export/manifest.hseg.json"
    blob, report = package(profile, "human seg", [{
        "name": "scene_0001.jpg",
        "width": 100,
        "height": 80,
        "content": b"image-bytes",
        "shapes": [{
            "label": "human",
            "type": "polygon",
            "points": [10, 10, 40, 10, 40, 50, 10, 50],
            "attributes": {},
        }],
    }])
    assert report["errors"] == [], report
    with zipfile.ZipFile(io.BytesIO(blob)) as archive:
        manifest = json.loads(archive.read("human_segmentation_export/manifest.hseg.json"))
        mask_name = "human_segmentation_export/masks/scene_0001/human_0001.png"
        assert mask_name in archive.namelist()
        assert "human_segmentation_export/images/scene_0001.jpg" in archive.namelist()
    instance = manifest["assets"][0]["instances"][0]
    assert manifest["format"] == "HSEG"
    assert instance["geometry"]["vertices"][0] == [10, 10]
    assert instance["mask_file"] == "masks/scene_0001/human_0001.png"
    refused = package(profile, "human seg", [{
        "name": "scene_0001.jpg",
        "width": 100,
        "height": 80,
        "content": b"image-bytes",
        "shapes": [{"label": "human", "type": "rectangle", "points": [1, 2, 3, 4]}],
    }])
    assert refused[0] is None


