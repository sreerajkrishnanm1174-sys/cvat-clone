from __future__ import annotations

import hashlib
import hmac
import json
import logging
import re
import secrets
from pathlib import Path

import httpx
from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from .config import Settings, get_settings
from .cvat import CvatClient, CvatError

from .db import ClientFormat, Prediction, Run, Sample, init_db, make_engine, make_session_factory
from .learning import MODE_TEXT, correction_summary, explain_profile, explain_rule, prompt_lessons, shapes_from_items
from . import exporting, planning, report, service, spec
from . import labelmemory
from .vision import annotate_image
from . import chat as agent_chat
from . import custom_format
from .service import get_project


class AnswerIn(BaseModel):
    question_id: str
    answer: str


class ApplyIn(BaseModel):
    confirm_type_changes: bool = False


class LearningSettingsIn(BaseModel):
    annotation_mode: str | None = None
    learn_enabled: bool | None = None
    compare_with_agent: bool | None = None
    allow_external_models: bool | None = None


class AnnotateIn(BaseModel):
    task_id: int
    mode: str | None = None
    shape: str | None = None


class CustomExportIn(BaseModel):
    profile: dict | None = None
    profile_id: int | None = None
    task_id: int | None = None
    job_id: int | None = None
    save: bool = False
    preview: bool = False


class RollbackIn(BaseModel):
    version: int = Field(ge=1)


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or get_settings()
    Path(settings.analyzer_data_dir).mkdir(parents=True, exist_ok=True)
    engine = make_engine(settings.database_url)
    init_db(engine)
    sessions = make_session_factory(engine)
    app = FastAPI(title="Requirement Analyzer", version="1.0.0", root_path=settings.analyzer_root_path)
    app.state.settings = settings
    app.state.sessions = sessions
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:8080", "http://localhost:3000"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    def db() -> Session:
        session = sessions()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def identity(
        authorization: str | None = Header(default=None),
        x_organization: str | None = Header(default=None),
    ) -> dict:
        if not authorization or " " not in authorization:
            raise HTTPException(status_code=401, detail="CVAT credentials are required")
        scheme, token = authorization.split(" ", 1)
        if scheme.lower() not in {"bearer", "token"} or not token:
            raise HTTPException(status_code=401, detail="CVAT credentials are required")
        return {
            "scheme": "Bearer" if scheme.lower() == "bearer" else "Token",
            "token": token,
            "organization": x_organization or "",
        }

    def cvat_client(who: dict = Depends(identity)) -> CvatClient:
        client = CvatClient(settings.cvat_base_url, who["token"], who["scheme"], who["organization"] or None)
        try:
            yield client
        finally:
            client.close()

    def open_project(project_id: int, client: CvatClient, session: Session, organization: str) -> tuple[dict, object]:
        try:
            project = client.get_project(project_id)
        except CvatError as exc:
            raise HTTPException(status_code=exc.status, detail="CVAT refused this project") from exc
        return project, get_project(session, project_id, organization)

    @app.get("/")
    def home() -> FileResponse:
        return FileResponse(Path(__file__).resolve().parent / "static" / "index.html")

    @app.post("/chat")
    def chat_agent(
        message: str = Form(""),
        history: str = Form("[]"),
        project_id: str = Form(""),
        task_id: str = Form(""),
        files: list[UploadFile] | None = File(default=None),
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        try:
            previous = json.loads(history or "[]")
        except json.JSONDecodeError:
            previous = []
        if not isinstance(previous, list):
            previous = []
        uploaded = []
        for item in files or []:
            uploaded.append((item.filename or "file", item.file.read()))
        bundle = agent_chat.read_upload(uploaded, Path(settings.analyzer_data_dir))
        project_key = int(project_id) if str(project_id or "").strip().isdigit() else None
        if project_key and bundle.get("document_name"):
            _store_requirement_copy(settings, project_key, bundle["document_name"])
        transcript = [item for item in previous if isinstance(item, dict)]
        context = []
        if str(project_id or "").strip().isdigit():
            context.append(f"Current project id: {int(project_id)}.")
        if str(task_id or "").strip().isdigit():
            context.append(f"Current task id: {int(task_id)}.")
        content = message.strip()
        if context:
            content = (content + "\n" + " ".join(context)).strip()
        transcript.append({"role": "user", "content": content})
        try:
            text = agent_chat.reply(settings, client, session, transcript, bundle)
        except RuntimeError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        download = None
        task_key = int(task_id) if str(task_id or "").strip().isdigit() else None
        if project_key and _user_wants_custom_export(message):
            text, download = _chat_export(settings, client, project_key, task_key, text, who["organization"])
        return {"reply": text, "download": download}

    @app.get("/exports/{token}")
    def download_ready_export(
        token: str,
        who: dict = Depends(identity),
    ) -> FileResponse:
        if not re.fullmatch(r"[a-f0-9]{32}", token or ""):
            raise HTTPException(status_code=404, detail="That export is not available")
        folder = Path(settings.analyzer_data_dir) / "exports"
        meta_path = folder / f"{token}.json"
        file_path = folder / f"{token}.zip"
        if not meta_path.exists() or not file_path.exists():
            raise HTTPException(status_code=404, detail="That export is not available")
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        if meta.get("organization") != (who["organization"] or ""):
            raise HTTPException(status_code=404, detail="That export is not available")
        return FileResponse(file_path, media_type="application/zip", filename=meta.get("filename") or "client-format.zip")

    @app.get("/health")
    def health() -> dict:
        return {"status": "ok"}

    @app.get("/version")
    def version() -> dict:
        return {"name": "requirement-analyzer", "version": "1.0.0"}

    @app.post("/projects/{project_id}/requirements")
    def upload_requirements(
        project_id: int,
        file: UploadFile = File(...),
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        _, state = open_project(project_id, client, session, who["organization"])
        destination = Path(settings.analyzer_data_dir) / "uploads" / str(project_id)
        destination.mkdir(parents=True, exist_ok=True)
        target = destination / Path(file.filename or "requirement.txt").name
        target.write_bytes(file.file.read())
        try:
            text = spec.read_document(target)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        parsed = _with_guide(spec.extract_spec(text), text, settings)
        service.save_spec(session, state, target.name, parsed)
        applied = _apply_spec(client, project_id, parsed)
        return {"spec": parsed, "version": state.spec_version, "applied": applied}

    @app.post("/projects/{project_id}/requirements/analyze")
    def analyze_requirement(
        project_id: int,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        _, state = open_project(project_id, client, session, who["organization"])
        folder = Path(settings.analyzer_data_dir) / "uploads" / str(project_id)
        text = ""
        document_name = "requirement"
        if folder.exists():
            files = [path for path in folder.iterdir() if path.is_file()]
            if files:
                latest = max(files, key=lambda path: path.stat().st_mtime)
                document_name = latest.name
                try:
                    text = spec.read_document(latest)
                except ValueError:
                    text = ""
        parsed = spec.extract_spec(text) if text else dict(state.spec_json or {})
        if not parsed.get("labels") and not text:
            raise HTTPException(status_code=400, detail="Upload a requirement before asking the agent to analyze it.")
        parsed = _with_guide(parsed, text, settings)
        service.save_spec(session, state, document_name, parsed)
        applied = _apply_spec(client, project_id, parsed)
        return {"spec": parsed, "version": state.spec_version, "applied": applied}

    @app.get("/projects/{project_id}/brief")
    def project_brief(
        project_id: int,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        _, state = open_project(project_id, client, session, who["organization"])
        return report.project_report(client, project_id, state.spec_json or {})

    @app.get("/projects/{project_id}/spec")
    def get_spec(
        project_id: int,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        _, state = open_project(project_id, client, session, who["organization"])
        return {"version": state.spec_version, "spec": state.spec_json or {}}

    @app.post("/projects/{project_id}/spec/answers")
    def answer(
        project_id: int,
        body: AnswerIn,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        _, state = open_project(project_id, client, session, who["organization"])
        try:
            updated = spec.apply_answer(state.spec_json or {}, body.question_id, body.answer)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        service.save_spec(session, state, "answer", updated)
        return {"spec": updated, "version": state.spec_version}

    @app.post("/projects/{project_id}/labels/preview")
    def preview_labels(
        project_id: int,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        _, state = open_project(project_id, client, session, who["organization"])
        existing = client.get_labels(project_id)
        return spec.diff_labels(state.spec_json or {}, existing)

    @app.post("/projects/{project_id}/labels/apply")
    def apply_labels(
        project_id: int,
        body: ApplyIn,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        _, state = open_project(project_id, client, session, who["organization"])
        existing = client.get_labels(project_id)
        diff = spec.diff_labels(state.spec_json or {}, existing)
        patch = service.label_patch(diff, existing, body.confirm_type_changes)
        if patch:
            try:
                client.patch_project_labels(project_id, patch)
            except CvatError as exc:
                raise HTTPException(status_code=exc.status, detail="CVAT refused the label update") from exc
        return {"applied": len(patch), "diff": spec.diff_labels(state.spec_json or {}, client.get_labels(project_id))}

    @app.get("/projects/{project_id}/plan")
    def plan(
        project_id: int,
        task_id: int,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        _, state = open_project(project_id, client, session, who["organization"])
        task = client.get_task(task_id)
        if task.get("project_id") not in {project_id, None}:
            raise HTTPException(status_code=404, detail="That task is not in this project")
        labels = (state.spec_json or {}).get("labels") or [
            {"name": item["name"], "type": item.get("type")} for item in client.get_labels(project_id)
        ]
        meta = client.get_task_meta(task_id)
        jobs = client.get_jobs(task_id=task_id)
        return service.dataset_plan(task, meta, jobs, labels, state.allow_external_models, None)

    @app.get("/projects/{project_id}/learning")
    def learning_view(
        project_id: int,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        _, state = open_project(project_id, client, session, who["organization"])
        explained = explain_profile(state.profile_json, state.finished_frames, state.annotation_mode)
        rules = (state.profile_json or {}).get("rules") or []
        explained["learn_enabled"] = state.learn_enabled
        explained["compare_with_agent"] = state.compare_with_agent
        explained["allow_external_models"] = state.allow_external_models
        explained["profile_version"] = state.profile_version
        explained["rules"] = rules
        explained["active_habits"] = [
            explain_rule(rule) for rule in rules if rule.get("status") == "active"
        ]
        explained["waiting"] = explained.get("unresolved") or []
        explained["running"] = 0
        explained["last_error"] = None
        explained["badge"] = "off" if not state.learn_enabled else "idle"
        rows = session.scalars(select(Sample).where(Sample.cvat_project_id == project_id)).all()
        explained["corrections"] = correction_summary(
            [{"items": row.items_json} for row in rows],
            state.profile_version,
        )
        return explained

    @app.post("/projects/{project_id}/learning/settings")
    def learning_settings(
        project_id: int,
        body: LearningSettingsIn,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        _, state = open_project(project_id, client, session, who["organization"])
        if body.annotation_mode:
            if body.annotation_mode not in MODE_TEXT:
                raise HTTPException(status_code=400, detail="Unknown annotation mode")
            state.annotation_mode = body.annotation_mode
        if body.learn_enabled is not None:
            state.learn_enabled = body.learn_enabled
        if body.compare_with_agent is not None:
            state.compare_with_agent = body.compare_with_agent
        if body.allow_external_models is not None:
            state.allow_external_models = body.allow_external_models
        _ensure_webhook(client, state, settings)
        return {
            "annotation_mode": state.annotation_mode,
            "mode_text": MODE_TEXT[state.annotation_mode],
            "learn_enabled": state.learn_enabled,
            "compare_with_agent": state.compare_with_agent,
            "allow_external_models": state.allow_external_models,
            "webhook_id": state.webhook_id,
        }

    @app.post("/projects/{project_id}/learning/reset")
    def reset_learning(
        project_id: int,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        _, state = open_project(project_id, client, session, who["organization"])
        session.query(Sample).filter(Sample.cvat_project_id == project_id).delete()
        session.query(Prediction).filter(Prediction.cvat_project_id == project_id).delete()
        state.profile_json = {"rules": []}
        state.profile_version = 0
        state.finished_frames = 0
        return {"forgotten": True, "summary": "The agent has learned from 0 finished frames."}

    @app.post("/projects/{project_id}/learning/rollback")
    def rollback(
        project_id: int,
        body: RollbackIn,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        _, state = open_project(project_id, client, session, who["organization"])
        try:
            profile = service.rollback_profile(session, state, body.version)
        except KeyError:
            raise HTTPException(status_code=404, detail="That profile version does not exist") from None
        return {"profile_version": state.profile_version, "rules": profile.get("rules") or []}

    @app.post("/projects/{project_id}/annotate")
    def annotate(
        project_id: int,
        body: AnnotateIn,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        _, state = open_project(project_id, client, session, who["organization"])
        if body.mode:
            if body.mode not in MODE_TEXT:
                raise HTTPException(status_code=400, detail="Unknown annotation mode")
            state.annotation_mode = body.mode
        run = Run(
            cvat_project_id=project_id,
            task_id=body.task_id,
            status="running",
            mode=state.annotation_mode,
            profile_version=state.profile_version if state.learn_enabled else 0,
        )
        session.add(run)
        session.flush()
        try:
            summary = run_annotation(session, client, state, body.task_id, run, settings, shape=body.shape or "auto")
        except CvatError as exc:
            run.status = "failed"
            run.message = "CVAT refused the annotation write"
            raise HTTPException(status_code=exc.status, detail=run.message) from exc
        return {"run_id": run.id, "status": run.status, "message": run.message, **summary}

    @app.get("/runs/{run_id}")
    def run_status(run_id: int, _: dict = Depends(identity), session: Session = Depends(db)) -> dict:
        run = session.get(Run, run_id)
        if run is None:
            raise HTTPException(status_code=404, detail="Run not found")
        return {
            "id": run.id,
            "status": run.status,
            "progress": run.progress,
            "total": run.total,
            "message": run.message,
        }

    @app.post("/runs/{run_id}/cancel")
    def cancel_run(run_id: int, _: dict = Depends(identity), session: Session = Depends(db)) -> dict:
        run = session.get(Run, run_id)
        if run is None:
            raise HTTPException(status_code=404, detail="Run not found")
        run.cancel_requested = True
        return {"cancel_requested": True}

    @app.post("/projects/{project_id}/sync")
    def sync_project(
        project_id: int,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        _, state = open_project(project_id, client, session, who["organization"])
        learned = learn_finished_jobs(session, client, state, settings)
        return {"samples": learned, "finished_frames": state.finished_frames}

    @app.get("/projects/{project_id}/label-memory")
    def label_memory(
        project_id: int,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        """What the agent has learned about each project label from manual annotation."""
        _, state = open_project(project_id, client, session, who["organization"])
        try:
            names = [item["name"] for item in _annotation_labels(client.get_labels(project_id))]
        except CvatError as exc:
            raise HTTPException(status_code=exc.status, detail="CVAT could not read the labels") from exc
        rows = session.scalars(select(Sample).where(Sample.cvat_project_id == project_id)).all()
        notes = labelmemory.derive_label_notes(
            [{"frame_key": f"{row.job_id}:{row.frame}", "items": row.items_json} for row in rows]
        )
        report = labelmemory.memory_report(session, project_id, names, notes)
        return {
            "label_source": "requirement and CVAT" if (state.spec_json or {}).get("labels") else "CVAT project labels",
            "learning_enabled": state.learn_enabled,
            "finished_frames": state.finished_frames,
            **report,
        }

    @app.delete("/projects/{project_id}/label-memory")
    def forget_label_memory(
        project_id: int,
        label: str | None = None,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        open_project(project_id, client, session, who["organization"])
        return {"removed": labelmemory.reset_memory(session, project_id, label)}

    @app.post("/projects/{project_id}/jobs/{job_id}/learn")
    def learn_saved_job(
        project_id: int,
        job_id: int,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        _, state = open_project(project_id, client, session, who["organization"])
        if not state.learn_enabled:
            return {"samples": 0, "skipped": True, "finished_frames": state.finished_frames}
        try:
            job = client.get_job(job_id)
        except CvatError as exc:
            raise HTTPException(status_code=exc.status, detail="CVAT could not read that job") from exc
        if job.get("project_id") != project_id:
            raise HTTPException(status_code=404, detail="That job is not in this project")
        learned = learn_job(session, client, state, job, settings, event_key="user-edit", apply_forward=True)
        return {
            "samples": learned,
            "skipped": False,
            "finished_frames": state.finished_frames,
            "rules": len((state.profile_json or {}).get("rules") or []),
        }

    @app.post("/projects/{project_id}/jobs/{job_id}/unlearn")
    def unlearn_job(
        project_id: int,
        job_id: int,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        _, state = open_project(project_id, client, session, who["organization"])
        session.query(Sample).filter(
            Sample.cvat_project_id == project_id,
            Sample.job_id == job_id,
        ).delete()
        service.rebuild_profile(session, state)
        return {"finished_frames": state.finished_frames, "removed_job_id": job_id}

    @app.get("/projects/{project_id}/export")
    def export_requirement_format(
        project_id: int,
        task_id: int | None = None,
        job_id: int | None = None,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ):
        _, state = open_project(project_id, client, session, who["organization"])
        parsed = state.spec_json or {}
        saved = _requirement_files(settings, project_id)
        if saved:
            profile = custom_format.analyze_files(saved)
            if profile.get("ready"):
                try:
                    images = _client_images(client, project_id, task_id, job_id)
                except CvatError as exc:
                    raise HTTPException(status_code=exc.status, detail="CVAT could not read the annotations for this export") from exc
                if profile.get("layout") == "hseg":
                    _attach_frames(client, images)
                project = client.get_project(project_id)
                blob, report = custom_format.package(profile, str(project.get("name") or f"project-{project_id}"), images)
                if blob is None:
                    message = (report.get("errors") or ["The requirement format did not pass verification."])[0]
                    return JSONResponse(status_code=422, content={"converted": False, "message": message, "report": report})
                filename = f"project-{project_id}-client-format.zip"
                return Response(
                    blob,
                    media_type="application/zip",
                    headers={"Content-Disposition": f'attachment; filename="{filename}"'},
                )
        output_format = parsed.get("output_format") or "CVAT"
        kind = exporting.export_kind(output_format)
        if not kind:
            return {
                "converted": False,
                "output_format": output_format,
                "message": "The requirement does not name an output format other than CVAT.",
            }
        try:
            images = _client_images(client, project_id, task_id, job_id)
        except CvatError as exc:
            raise HTTPException(status_code=exc.status, detail="CVAT could not read the annotations for this export") from exc
        orders = {
            item["name"]: list(item.get("keypoints") or [])
            for item in parsed.get("labels") or []
            if item.get("name")
        }
        for image in images:
            for shape in image["shapes"]:
                if orders.get(shape["label"]):
                    shape["keypoint_order"] = orders[shape["label"]]
        label_names = [item["name"] for item in parsed.get("labels") or [] if item.get("name")]
        blob = exporting.build_archive(kind, output_format, label_names, images)
        filename = f"project-{project_id}-{kind}.zip"
        return Response(
            blob,
            media_type="application/zip",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )

    @app.post("/projects/{project_id}/custom-format/analyze")
    def analyze_custom_format(
        project_id: int,
        files: list[UploadFile] | None = File(default=None),
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        open_project(project_id, client, session, who["organization"])
        if files:
            payload = [(item.filename or "requirement.txt", item.file.read()) for item in files]
        else:
            payload = _requirement_files(settings, project_id)
        if not payload:
            return {"profile": custom_format.analyze_files([]), "ready": False, "ambiguities": ["This project has no requirement document yet."]}
        profile = custom_format.analyze_files(payload)
        return {"profile": profile, "ready": bool(profile.get("ready")), "ambiguities": profile.get("ambiguities") or []}

    @app.get("/projects/{project_id}/custom-format/profiles")
    def list_custom_formats(
        project_id: int,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        open_project(project_id, client, session, who["organization"])
        rows = session.scalars(
            select(ClientFormat).where(ClientFormat.organization == (who["organization"] or "")).order_by(ClientFormat.id.desc())
        ).all()
        return {
            "profiles": [
                {"id": row.id, "name": row.name, "document_name": row.document_name, "version": row.version, "project_id": row.cvat_project_id}
                for row in rows
            ]
        }

    @app.post("/projects/{project_id}/custom-format/export")
    def export_custom_format(
        project_id: int,
        body: CustomExportIn,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ):
        project, _state = open_project(project_id, client, session, who["organization"])
        profile = _load_custom_profile(session, body, project_id, who["organization"])
        if body.save and body.profile and profile.get("ready"):
            row = ClientFormat(
                organization=who["organization"] or "",
                cvat_project_id=project_id,
                name=str(profile.get("name") or "Client format")[:160],
                document_name=str(profile.get("document_name") or "")[:256],
                profile_json=profile,
            )
            session.add(row)
            session.flush()
        try:
            images = _client_images(client, project_id, body.task_id, body.job_id)
        except CvatError as exc:
            raise HTTPException(status_code=exc.status, detail="CVAT could not read the annotations for this export") from exc
        if body.preview:
            images = images[:2]
        blob, report = custom_format.package(profile, str(project.get("name") or f"project-{project_id}"), images)
        if blob is None:
            return JSONResponse(status_code=422, content={"ready": False, "report": report})
        if body.preview:
            preview, _ = custom_format.convert_dataset(profile, str(project.get("name") or ""), images)
            return {"ready": True, "report": report, "preview": preview}
        filename = f"project-{project_id}-client-format.zip"
        return Response(blob, media_type="application/zip", headers={"Content-Disposition": f'attachment; filename="{filename}"'})

    @app.get("/projects/{project_id}/jobs/{job_id}/diff")
    def job_diff(
        project_id: int,
        job_id: int,
        who: dict = Depends(identity),
        client: CvatClient = Depends(cvat_client),
        session: Session = Depends(db),
    ) -> dict:
        open_project(project_id, client, session, who["organization"])
        labels = {item["id"]: item for item in client.get_labels(project_id)}
        annotations = client.get_annotations("jobs", job_id)
        frames = service.group_frames(annotations, labels)
        diff = []
        for frame, shapes in sorted(frames.items()):
            snapshot = service.latest_snapshot(session, project_id, job_id, frame)
            diff.append(
                {
                    "frame": frame,
                    "agent": snapshot,
                    "final": shapes,
                    "items": service.learning.classify_frame(snapshot, shapes),
                }
            )
        return {"frames": diff}

    @app.post("/webhooks/cvat")
    async def cvat_webhook(request: Request, session: Session = Depends(db)) -> dict:
        raw = await request.body()
        _verify_signature(raw, request.headers.get("x-signature-256"), settings.webhook_secret)
        payload = json.loads(raw.decode("utf-8"))
        event = payload.get("event")
        job = payload.get("job") or {}
        dedupe = ":".join(
            [
                str(payload.get("webhook_id") or ""),
                str(event or ""),
                str(job.get("id") or payload.get("task", {}).get("id") or ""),
                str(job.get("updated_date") or ""),
            ]
        )
        if not service.remember_event(session, dedupe, {"event": event, "job_id": job.get("id")}):
            return {"status": "duplicate"}
        if event == "update:job" and job.get("state") == "completed" and job.get("project_id"):
            if not settings.cvat_access_token:
                return {"status": "stored", "learning": "waiting_for_service_token"}
            worker = CvatClient(
                settings.cvat_base_url,
                settings.cvat_access_token,
                settings.cvat_auth_scheme,
                None,
            )
            try:
                state = get_project(session, int(job["project_id"]))
                learned = learn_job(session, worker, state, job, settings)
            finally:
                worker.close()
            return {"status": "learned", "samples": learned}
        return {"status": "ignored"}

    @app.get("/agents")
    def agents() -> dict:
        return {
            "available": "The agent reads the requirement and annotates each task image directly.",
            "cvat_models": "CVAT's YOLO and SAM models are not used for this annotation.",
        }

    app.state.identity = identity
    app.state.cvat_client = cvat_client
    app.state.db = db
    return app


def _verify_signature(raw: bytes, header: str | None, secret: str) -> None:
    if not secret:
        raise HTTPException(status_code=401, detail="Webhook secret is not configured")
    if not header or not header.startswith("sha256="):
        raise HTTPException(status_code=401, detail="Missing webhook signature")
    expected = hmac.new(secret.encode("utf-8"), raw, hashlib.sha256).hexdigest()
    provided = header.split("=", 1)[1]
    if not hmac.compare_digest(expected, provided):
        raise HTTPException(status_code=401, detail="Invalid webhook signature")


def _ensure_webhook(client: CvatClient, state, settings: Settings) -> None:
    if state.webhook_id or not settings.analyzer_webhook_url or not settings.webhook_secret:
        return
    try:
        created = client.create_webhook(
            state.cvat_project_id,
            settings.analyzer_webhook_url,
            settings.webhook_secret,
            ["update:job", "update:task"],
        )
    except CvatError:
        return
    state.webhook_id = created.get("id")


def _apply_spec(client: CvatClient, project_id: int, parsed: dict) -> int:
    existing = client.get_labels(project_id)
    replace_ids = set(service.skeleton_ids_to_replace(parsed, existing))
    replaced = 0
    if replace_ids:
        client.patch_project_labels(project_id, [{"id": label_id, "deleted": True} for label_id in replace_ids])
        existing = [
            item
            for item in existing
            if item.get("id") not in replace_ids and item.get("parent_id") not in replace_ids
        ]
        replaced = len(replace_ids)
    diff = spec.diff_labels(parsed, existing)
    patch = service.label_patch(diff, existing, False)
    if patch:
        client.patch_project_labels(project_id, patch)
    return replaced + len(patch)


def _with_guide(parsed: dict, text: str, settings: Settings) -> dict:
    from .vision import VisionError, analyze_requirement

    try:
        guide = analyze_requirement(settings.anthropic_api_key, settings.anthropic_model, text, parsed)
    except (VisionError, httpx.HTTPError):
        guide = spec.explain_requirement(parsed)
    return spec.apply_guide(parsed, guide)


def run_annotation(session: Session, client: CvatClient, state, task_id: int, run: Run, settings: Settings, detect=None, shape: str = "auto") -> dict:
    task = client.get_task(task_id)
    in_project = task.get("project_id") == state.cvat_project_id
    if not in_project and task.get("project_id") is not None:
        raise HTTPException(status_code=404, detail="That task is not in this project")
    # A task inside the project uses the project's labels. A task created without a project keeps its own.
    labels = client.get_labels(state.cvat_project_id) if in_project else client.get_task_labels(task_id)
    jobs = client.get_jobs(task_id=task_id)
    if not int(task.get("size") or 0) or not jobs:
        run.status = "finished"
        run.message = "This task has no images yet. Choose the image files, create the task, and wait until CVAT finishes importing them."
        return {"written": 0, "flagged": 0, "message": run.message}
    if state.learn_enabled:
        learn_finished_jobs(session, client, state, settings)
        if not in_project:
            for job in jobs:
                learn_job(session, client, state, job, settings, event_key="user-edit")
    profile = state.profile_json if state.learn_enabled else {"rules": []}
    lesson_rows = session.scalars(select(Sample).where(Sample.cvat_project_id == state.cvat_project_id)).all()
    lessons = prompt_lessons(profile, [{"items": row.items_json} for row in lesson_rows]) if state.learn_enabled else []
    labels = _annotation_labels(labels)
    spec_by_name = {item["name"]: item for item in (state.spec_json or {}).get("labels") or []}
    spec_labels = []
    for item in labels:
        extra = spec_by_name.get(item["name"]) or {}
        sublabels = item.get("sublabels") or []
        keypoints = [sub.get("name") for sub in sublabels if sub.get("name")] or list(extra.get("keypoints") or [])
        cvat_type = item.get("type")
        spec_labels.append(
            {
                "name": item["name"],
                "type": cvat_type if cvat_type not in {None, "", "any"} else extra.get("type") or "any",
                "attributes": item.get("attributes") or [],
                "detect_as": extra.get("detect_as") or [],
                "min_size": extra.get("min_size"),
                "keypoints": keypoints,
                "edges": list(extra.get("edges") or []),
                "how_to_annotate": extra.get("how_to_annotate") or "",
                "how_to_decide": extra.get("how_to_decide") or "",
            }
        )
    if not spec_labels:
        run.status = "finished"
        where = "project" if in_project else "task (it is not in a project)"
        run.message = (
            f"No labels were found on this {where}. Add the labels in CVAT on the "
            f"{'project' if in_project else 'task'}, or upload a requirement and apply its labels."
        )
        return {"written": 0, "flagged": 0, "message": run.message}
    has_requirement = bool((state.spec_json or {}).get("labels"))
    notes: dict[str, dict] = {}
    exemplars: list[dict] = []
    if state.learn_enabled:
        notes = labelmemory.derive_label_notes([{"frame_key": f"{row.job_id}:{row.frame}", "items": row.items_json} for row in lesson_rows])
        labelmemory.apply_notes(spec_labels, notes)
        exemplars = labelmemory.select_exemplars(session, state.cvat_project_id, [item["name"] for item in spec_labels])
    requested = (shape or "auto").strip().lower()
    if requested not in {"auto", "rectangle", "polygon", "mask", "polyline", "points", "ellipse", "skeleton", "cuboid"}:
        run.status = "finished"
        run.message = "That annotation shape is not supported."
        return {"written": 0, "flagged": 0, "message": run.message}
    if requested != "auto":
        spec_labels = [item for item in spec_labels if item.get("type") == requested]
        if not spec_labels:
            run.status = "finished"
            run.message = f"This project has no {requested} label, so that shape was not drawn."
            return {"written": 0, "flagged": 0, "message": run.message}
    written = 0
    flagged = 0
    found = matched = invalid = 0
    manual_frames: set[int] = set()
    run.total = sum(int(job.get("stop_frame", 0)) - int(job.get("start_frame", 0)) + 1 for job in jobs)
    video = task.get("mode") == "interpolation"
    frame_size = (0, 0)
    if video:
        meta = client.get_task_meta(task_id)
        for info in meta.get("frames") or []:
            width = int(info.get("width") or 0)
            height = int(info.get("height") or 0)
            if width and height:
                frame_size = (width, height)
                break
    for job in jobs:
        if run.cancel_requested:
            run.status = "cancelled"
            return {"written": written, "flagged": flagged}
        start = int(job.get("start_frame") or 0)
        stop = int(job.get("stop_frame") or start)
        try:
            client.clear_review_issues(int(job["id"]))
        except CvatError:
            pass
        existing = client.get_annotations("jobs", job["id"])
        manual_frames = {
            int(shape.get("frame") or 0)
            for shape in existing.get("shapes") or []
            if shape.get("source") == "manual"
        }
        per_frame: dict[int, list[dict]] = {}
        for frame in range(start, stop + 1):
            if run.cancel_requested:
                run.status = "cancelled"
                return {"written": written, "flagged": flagged}
            run.progress += 1
            if frame in manual_frames:
                continue
            raw = _detect(client, settings, task_id, frame, spec_labels, detect, lessons, exemplars)
            adapted = service.shapes_for_labels(raw, spec_labels, profile)
            found += len(raw)
            matched += len(adapted)
            per_frame[frame] = adapted
        if video and per_frame:
            per_frame = service.associate_by_iou(
                per_frame,
                minimum=settings.track_match_minimum,
                gap=settings.track_lost_frames,
                gate=settings.track_gate,
                high_confidence=settings.track_high_confidence,
            )
            per_frame = service.stabilize_tracks(per_frame, frame_size)
            from .segment import trace_polygons

            per_frame = service.recover_drifted(
                per_frame,
                lambda frame, task_id=task_id: client.get_frame(task_id, frame),
                trace_polygons,
            )
        elif len(per_frame) > 1:
            per_frame = service.associate_by_iou(
                per_frame,
                minimum=settings.track_match_minimum,
                gap=settings.track_lost_frames,
                gate=settings.track_gate,
                high_confidence=settings.track_high_confidence,
            )
        cvat_shapes = []
        cvat_tracks = service.to_cvat_tracks(
            per_frame,
            {item["name"]: item for item in labels},
            end_frame=stop,
            frame_size=frame_size,
        ) if video else []
        for frame, shapes in per_frame.items():
            session.add(
                Prediction(
                    run_id=run.id,
                    cvat_project_id=state.cvat_project_id,
                    task_id=task_id,
                    job_id=job["id"],
                    frame=frame,
                    profile_version=run.profile_version,
                    shapes_json=shapes,
                )
            )
            for shape in shapes:
                if not video:
                    payload = service.to_cvat_shape(shape, {item["name"]: item for item in labels}, frame)
                    if payload:
                        cvat_shapes.append(payload)
                        written += 1
                    else:
                        invalid += 1
        kept = [
            shape
            for shape in existing.get("shapes") or []
            if int(shape.get("frame") or 0) in manual_frames
        ]
        if video:
            written += sum(1 for track in cvat_tracks for item in track["shapes"] if not item.get("outside"))
        manual_tracks = [
            track
            for track in existing.get("tracks") or []
            if track.get("source") == "manual"
        ]
        if cvat_shapes or cvat_tracks or kept != (existing.get("shapes") or []):
            client.put_annotations(
                "jobs",
                job["id"],
                {
                    "version": existing.get("version") or 0,
                    "tags": existing.get("tags") or [],
                    "shapes": kept + cvat_shapes,
                    "tracks": (manual_tracks + cvat_tracks) if video else (existing.get("tracks") or []),
                },
            )
    run.status = "finished"
    if written == 0 and not manual_frames:
        detail = _detect_error or _empty_annotation_reason(spec_labels)
        if not _detect_error:
            if found == 0:
                detail = "The vision agent returned no objects for any image, so nothing was found to draw."
            elif matched == 0:
                detail = f"The agent found {found} object(s), but none had a name matching a project label."
            elif invalid:
                detail = (
                    f"The agent found {found} object(s) and {matched} matched a label, but {invalid} could not be "
                    "saved because their outline was invalid (polygon too small, self-crossing, or a mask without data)."
                )
        run.message = "No shapes were added. " + detail
    else:
        source = "the requirement" if has_requirement else "the project's labels in CVAT"
        parts = []
        if lessons:
            parts.append(f"Applied {len(lessons)} correction(s) learned from this project.")
        if exemplars:
            parts.append(f"Showed the agent {len(exemplars)} example(s) of what your annotators drew.")
        if notes:
            parts.append(f"Used habits learned for {len(notes)} label(s).")
        learned = (
            " " + " ".join(parts)
            if parts
            else f" Nothing has been learned from this project yet, so this pass follows {source}. "
            "Annotate a few images by hand, save, and the next pass learns from them."
        )
        run.message = (
            f"Added {written} shapes.{learned} "
            "Save your edits in this project and the next task follows them. "
            "Frames you already edited were left as you drew them."
        )
    return {"written": written, "flagged": flagged, "message": run.message}


_detect_error = ""


def _annotation_labels(labels: list[dict]) -> list[dict]:
    """Keep project labels and attach skeleton joints. Joints are not separate labels."""
    children: dict[int, list[dict]] = {}
    for item in labels:
        parent = item.get("parent_id")
        if parent:
            children.setdefault(int(parent), []).append(item)
    prepared = []
    for item in labels:
        if item.get("parent_id") or item.get("has_parent"):
            continue
        copy = dict(item)
        if not copy.get("sublabels"):
            copy["sublabels"] = children.get(int(item["id"]), []) if item.get("id") is not None else []
        prepared.append(copy)
    return prepared


def _empty_annotation_reason(labels: list[dict]) -> str:
    skeletons = [item["name"] for item in labels if item.get("type") == "skeleton"]
    if skeletons:
        joints = []
        for item in labels:
            if item.get("type") == "skeleton":
                joints.extend(item.get("keypoints") or [])
        if joints:
            return "The skeleton keypoints were not found on the image: " + ", ".join(joints[:12]) + "."
        return "This project expects a skeleton, but the label has no keypoints. Analyze the requirement again."
    return "The vision agent did not find any labels that belong to this project."


def _detect(client, settings: Settings, task_id: int, frame: int, labels: list[dict], detect, lessons: list[str] | None = None, exemplars: list[dict] | None = None) -> list[dict]:
    global _detect_error
    if detect is not None:
        return detect(frame, labels)
    if not settings.anthropic_api_key:
        _detect_error = "The agent annotates the task images directly and needs an API key."
        return []
    image = client.get_frame(task_id, frame)
    try:
        raw = annotate_image(
            settings.anthropic_api_key,
            settings.anthropic_model,
            image,
            labels,
            lessons or [],
            refine=settings.annotation_refine,
            exemplars=exemplars,
        )
    except Exception as exc:
        _detect_error = str(exc)[:240]
        return []
    _detect_error = ""
    return raw


def _spread_track(track: dict, start: int, stop: int) -> list[tuple[int, dict]]:
    """Repeat a CVAT track on every frame it stays visible, including frames between keyframes."""
    keyframes = sorted(
        (shape for shape in track.get("shapes") or [] if shape.get("frame") is not None),
        key=lambda item: int(item["frame"]),
    )
    placed = []
    for index, shape in enumerate(keyframes):
        if shape.get("outside"):
            continue
        frame = int(shape["frame"])
        nxt = keyframes[index + 1] if index + 1 < len(keyframes) else None
        last = int(nxt["frame"]) if nxt is not None else stop + 1
        for current in range(max(frame, start), min(max(last, frame + 1), stop + 1)):
            placed.append((current, _shape_at(shape, nxt, current, track)))
    return placed


def _shape_at(shape: dict, nxt: dict | None, frame: int, track: dict) -> dict:
    copy = dict(shape)
    copy["label_id"] = track.get("label_id")
    copy["track_id"] = track.get("id")
    copy["frame"] = frame
    if nxt is None or nxt.get("outside") or int(nxt.get("frame") or frame) <= frame:
        return copy
    if (shape.get("type") or "") == "mask" or (nxt.get("type") or "") == "mask":
        return copy
    left = [float(value) for value in shape.get("points") or []]
    right = [float(value) for value in nxt.get("points") or []]
    if len(left) != len(right) or len(left) < 2:
        return copy
    span = int(nxt["frame"]) - int(shape["frame"])
    if span <= 0:
        return copy
    weight = (frame - int(shape["frame"])) / span
    copy["points"] = [round(left[index] + (right[index] - left[index]) * weight, 2) for index in range(len(left))]
    return copy


def _client_images(client: CvatClient, project_id: int, task_id: int | None, job_id: int | None) -> list[dict]:
    labels = {int(item["id"]): item for item in client.get_labels(project_id) if item.get("id") is not None}
    if job_id:
        job = client.get_job(int(job_id))
        if job.get("project_id") != project_id:
            raise HTTPException(status_code=404, detail="That job is not in this project")
        jobs = [job]
    elif task_id:
        task = client.get_task(int(task_id))
        if task.get("project_id") != project_id:
            raise HTTPException(status_code=404, detail="That task is not in this project")
        jobs = client.get_jobs(task_id=int(task_id))
    else:
        jobs = []
        for task in client.list_project_tasks(project_id):
            jobs.extend(client.get_jobs(task_id=int(task["id"])))
    images = []
    used_names: set[str] = set()
    meta_cache: dict[int, dict] = {}
    for job in jobs:
        task_key = int(job.get("task_id") or 0)
        if task_key not in meta_cache:
            meta_cache[task_key] = client.get_task_meta(task_key)
        frames = meta_cache[task_key].get("frames") or []
        grouped: dict[int, list[dict]] = {}
        annotations = client.get_annotations("jobs", int(job["id"]))
        start = int(job.get("start_frame") or 0)
        stop = int(job.get("stop_frame") or start)
        for shape in annotations.get("shapes") or []:
            grouped.setdefault(int(shape.get("frame") or 0), []).append(shape)
        for track in annotations.get("tracks") or []:
            for frame, shape in _spread_track(track, start, stop):
                grouped.setdefault(frame, []).append(shape)
        for frame in range(start, stop + 1):
            info = frames[frame] if 0 <= frame < len(frames) else {}
            name = str(info.get("name") or f"task_{task_key}_frame_{frame}.jpg")
            if name in used_names:
                name = f"task_{task_key}_{name}"
            used_names.add(name)
            images.append(
                {
                    "name": name,
                    "width": int(info.get("width") or 0),
                    "height": int(info.get("height") or 0),
                    "task_id": task_key,
                    "frame": frame,
                    "shapes": [_export_shape(shape, labels) for shape in grouped.get(frame, [])],
                }
            )
    return images


def _user_wants_custom_export(message: str) -> bool:
    return bool(re.search(r"export|download|hseg|custom format|client format|json v1|format example", message or "", flags=re.I))


def _store_requirement_copy(settings: Settings, project_id: int, document_name: str) -> None:
    source = Path(settings.analyzer_data_dir) / "chat" / Path(document_name).name
    if not source.is_file():
        return
    destination = Path(settings.analyzer_data_dir) / "uploads" / str(project_id)
    destination.mkdir(parents=True, exist_ok=True)
    target = destination / source.name
    target.write_bytes(source.read_bytes())


def _attach_frames(client: CvatClient, images: list[dict]) -> None:
    for image in images:
        if image.get("content") or image.get("task_id") is None or image.get("frame") is None:
            continue
        image["content"] = client.get_frame(int(image["task_id"]), int(image["frame"]))


def _chat_export(settings: Settings, client: CvatClient, project_id: int, task_id: int | None, reply: str, organization: str) -> tuple[str, dict | None]:
    saved = _requirement_files(settings, project_id)
    profile = custom_format.analyze_files(saved)
    if not profile.get("ready"):
        reason = (profile.get("ambiguities") or ["The requirement example is not ready to convert."])[0]
        return reason, None
    try:
        images = _client_images(client, project_id, task_id, None)
        if profile.get("layout") == "hseg":
            _attach_frames(client, images)
        project = client.get_project(project_id)
    except CvatError:
        return "CVAT could not read the annotations for this export.", None
    blob, report = custom_format.package(profile, str(project.get("name") or f"project-{project_id}"), images)
    if blob is None:
        return ((report.get("errors") or ["The client format did not pass verification."])[0]), None
    token = secrets.token_hex(16)
    folder = Path(settings.analyzer_data_dir) / "exports"
    folder.mkdir(parents=True, exist_ok=True)
    filename = f"project-{project_id}-{profile.get('layout') or 'client'}.zip"
    (folder / f"{token}.zip").write_bytes(blob)
    (folder / f"{token}.json").write_text(
        json.dumps({"organization": organization or "", "filename": filename}),
        encoding="utf-8",
    )
    message = f"Converted {report.get('converted') or 0} objects to {profile.get('name') or 'the client format'}. The file is downloading."
    if re.search(r"can.?t|cannot|from here", reply or "", flags=re.I):
        reply = message
    elif message not in (reply or ""):
        reply = (reply.rstrip() + " " + message).strip()
    return reply, {"token": token, "filename": filename}


def _requirement_files(settings: Settings, project_id: int) -> list[tuple[str, bytes]]:
    folder = Path(settings.analyzer_data_dir) / "uploads" / str(project_id)
    if not folder.exists():
        return []
    payload = []
    for path in sorted(folder.iterdir(), key=lambda item: item.stat().st_mtime):
        if path.is_file() and path.stat().st_size <= custom_format.MAX_BYTES:
            payload.append((path.name, path.read_bytes()))
    return payload


def _attribute_map(shape: dict) -> dict:
    raw = shape.get("attributes") or []
    if isinstance(raw, dict):
        values = {str(key): value for key, value in raw.items()}
    else:
        values = {}
        for item in raw if isinstance(raw, list) else []:
            if isinstance(item, dict) and item.get("name"):
                values[str(item["name"])] = item.get("value")
    values.setdefault("occluded", bool(shape.get("occluded")))
    return values


def _load_custom_profile(session: Session, body: CustomExportIn, project_id: int, organization: str) -> dict:
    if body.profile_id:
        row = session.get(ClientFormat, int(body.profile_id))
        if row is None or row.organization != (organization or ""):
            raise HTTPException(status_code=404, detail="That client format is not available in this organization")
        return dict(row.profile_json or {})
    if body.profile:
        return dict(body.profile)
    raise HTTPException(status_code=400, detail="Choose a saved client format or analyze a document first")


def _export_shape(shape: dict, labels: dict[int, dict]) -> dict:
    label = labels.get(int(shape.get("label_id") or 0), {})
    elements = []
    for element in shape.get("elements") or []:
        joint = labels.get(int(element.get("label_id") or 0), {})
        elements.append(
            {
                "name": joint.get("name") or "",
                "points": element.get("points") or [],
                "outside": bool(element.get("outside")),
                "occluded": bool(element.get("occluded")),
            }
        )
    return {
        "label": label.get("name") or "",
        "type": shape.get("type") or label.get("type"),
        "points": shape.get("points") or [],
        "elements": elements,
        "keypoint_order": [],
        "id": shape.get("id"),
        "source": shape.get("source") or "",
            "occluded": bool(shape.get("occluded")),
            "attributes": _attribute_map(shape),
            "track_id": shape.get("track_id") or "",
        }


def learn_job(session: Session, client: CvatClient, state, job: dict, settings: Settings, event_key: str | None = None, apply_forward: bool = False) -> int:
    if not state.learn_enabled:
        return 0
    if job.get("project_id") is None and job.get("task_id"):
        labels = {item["id"]: item for item in client.get_task_labels(int(job["task_id"]))}
    else:
        labels = {item["id"]: item for item in client.get_labels(state.cvat_project_id)}
    annotations = client.get_annotations("jobs", job["id"])
    frames = service.group_frames(annotations, labels)
    event_key = event_key or str(job.get("updated_date") or job.get("id"))
    job_id = int(job["id"])
    previous = {
        int(row.frame): shapes_from_items(row.items_json)
        for row in session.scalars(
            select(Sample).where(
                Sample.cvat_project_id == state.cvat_project_id,
                Sample.job_id == job_id,
                Sample.event_key == event_key,
            )
        ).all()
    }
    predicted: dict[int, list] = {}
    for row in session.scalars(
        select(Prediction)
        .where(Prediction.cvat_project_id == state.cvat_project_id, Prediction.job_id == job_id)
        .order_by(Prediction.id.desc())
    ).all():
        predicted.setdefault(int(row.frame), list(row.shapes_json or []))
    frame_ids = set(frames) | set(previous) | set(predicted)
    count = 0
    for frame in sorted(frame_ids):
        snapshot = predicted.get(frame) or previous.get(frame) or []
        if state.compare_with_agent and not snapshot:
            snapshot = _quiet_comparison(client, settings, int(job.get("task_id") or 0), int(frame), list(labels.values()))
        items = service.record_frame(
            session,
            state,
            task_id=int(job.get("task_id") or 0),
            job_id=job_id,
            frame=int(frame),
            event_key=event_key,
            snapshot=snapshot,
            final=frames.get(frame, []),
        )
        try:
            labelmemory.capture_frame(
                session,
                client,
                state.cvat_project_id,
                int(job.get("task_id") or 0),
                job_id,
                int(frame),
                items,
                known_labels={item.get("name") for item in labels.values()},
            )
        except Exception:  # learning what a label looks like must never break saving or annotating
            logging.getLogger(__name__).exception("label memory capture failed")
        count += 1
    if apply_forward and frames:
        snapshots = {
            frame: service.latest_snapshot(session, state.cvat_project_id, job["id"], frame)
            for frame in frames
        }
        updated = service.carry_track_corrections(annotations, snapshots)
        if updated:
            client.put_annotations("jobs", job["id"], updated)
    if count == 0:
        service.record_frame(
            session,
            state,
            task_id=int(job.get("task_id") or 0),
            job_id=job_id,
            frame=int(job.get("start_frame") or 0),
            event_key=event_key,
            snapshot=[],
            final=[],
        )
        count = 1
    return count


def learn_finished_jobs(session: Session, client: CvatClient, state, settings: Settings) -> int:
    jobs = client.get_jobs(project_id=state.cvat_project_id)
    total = 0
    for job in jobs:
        total += learn_job(session, client, state, job, settings, event_key="user-edit")
    return total


def _quiet_comparison(client: CvatClient, settings: Settings, task_id: int, frame: int, labels: list[dict]) -> list[dict]:
    """Learning uses the shapes already stored from the direct annotation pass."""
    return []


app = create_app()
